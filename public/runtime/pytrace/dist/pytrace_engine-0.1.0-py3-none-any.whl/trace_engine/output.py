"""Bounded append-only stdout and stderr accounting."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

StreamName = Literal["stdout", "stderr"]


def normalize_output_text(text: str) -> str:
    """Replace lone surrogates while preserving ordinary Unicode text."""

    if type(text) is not str:
        raise TypeError("output must be an exact string")
    return text.encode("utf-8", "backslashreplace").decode("utf-8")


def _prefix_at_utf8_boundary(payload: bytes, limit: int) -> str:
    return payload[:limit].decode("utf-8", "ignore")


@dataclass(slots=True)
class OutputAccumulator:
    """Collect per-step deltas under one shared byte ceiling."""

    max_bytes: int
    stdout_bytes: int = 0
    stderr_bytes: int = 0
    output_truncated: bool = False
    _stdout_delta: str = ""
    _stderr_delta: str = ""

    def __post_init__(self) -> None:
        if type(self.max_bytes) is not int or self.max_bytes <= 0:
            raise ValueError("max_bytes must be a positive integer")

    @property
    def total_bytes(self) -> int:
        return self.stdout_bytes + self.stderr_bytes

    def write(self, stream: StreamName, text: str) -> int:
        """Append safe text and return the accepted UTF-8 byte count."""

        if stream not in ("stdout", "stderr"):
            raise ValueError("stream must be stdout or stderr")
        if self.output_truncated:
            return 0

        normalized = normalize_output_text(text)
        encoded = normalized.encode("utf-8")
        remaining = self.max_bytes - self.total_bytes
        if len(encoded) > remaining:
            normalized = _prefix_at_utf8_boundary(encoded, remaining)
            encoded = normalized.encode("utf-8")
            self.output_truncated = True

        if stream == "stdout":
            self._stdout_delta += normalized
            self.stdout_bytes += len(encoded)
        else:
            self._stderr_delta += normalized
            self.stderr_bytes += len(encoded)
        return len(encoded)

    def take_delta(self) -> dict[str, str | int]:
        """Return and clear the current deltas while retaining offsets."""

        result: dict[str, str | int] = {
            "stdout_delta": self._stdout_delta,
            "stderr_delta": self._stderr_delta,
            "stdout_bytes": self.stdout_bytes,
            "stderr_bytes": self.stderr_bytes,
        }
        self._stdout_delta = ""
        self._stderr_delta = ""
        return result

"""Dependency-free Python trace engine contracts."""

__version__ = "0.1.0"

from .api import (
    CallableInputProvider,
    InputCancelled,
    InputProvider,
    ListTraceSink,
    QueueInputProvider,
    RunSummary,
    TraceConflictError,
    TraceSink,
)
from .engine import collect_trace, run_in_process
from .native import SubprocessSession
from .options import TraceOptions
from .serialization import (
    RecordLimitError,
    SerializationError,
    TraceBudget,
    TraceLimitError,
    canonical_record_bytes,
    finalize_terminal,
    record_size,
)
from .validation import StreamValidationError, validate_stream_semantics

__all__ = [
    "CallableInputProvider",
    "InputCancelled",
    "InputProvider",
    "ListTraceSink",
    "QueueInputProvider",
    "RecordLimitError",
    "RunSummary",
    "SerializationError",
    "StreamValidationError",
    "SubprocessSession",
    "TraceBudget",
    "TraceConflictError",
    "TraceLimitError",
    "TraceOptions",
    "TraceSink",
    "__version__",
    "canonical_record_bytes",
    "collect_trace",
    "finalize_terminal",
    "record_size",
    "run_in_process",
    "validate_stream_semantics",
]

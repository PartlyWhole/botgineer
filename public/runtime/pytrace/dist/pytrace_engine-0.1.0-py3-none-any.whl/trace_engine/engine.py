"""Trusted in-process tracing host built on direct ``sys.settrace``."""

from __future__ import annotations

import builtins
import dis
import hashlib
import inspect
import os
import platform
import sys
import threading
import types
import warnings
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from typing import Any, TextIO, cast

from ._snapshot import (
    ExceptionEvent,
    InputEvent,
    SnapshotContext,
    SnapshotFrame,
    SnapshotGlobals,
    SnapshotLocation,
    ValueEvent,
    encode_snapshot,
)
from .api import (
    InputCancelled,
    InputProvider,
    ListTraceSink,
    QueueInputProvider,
    RunSummary,
    TerminalReason,
    TraceConflictError,
    TraceSink,
)
from .closures import ActiveInvocations, FunctionProvenanceResolver, LexicalParentMap
from .identity import FrameIdAllocator, IdentityRegistry
from .options import TraceOptions
from .output import OutputAccumulator, StreamName
from .records import Record
from .serialization import (
    RecordLimitError,
    TraceBudget,
    TraceLimitError,
)

_ENGINE_VERSION = "0.1.0"
_SYNTHETIC_FILENAME = "<pytrace>"
_MODULE_INTERNAL_NAMES = {
    "__builtins__",
    "__cached__",
    "__file__",
    "__loader__",
    "__name__",
    "__package__",
    "__spec__",
}


def _replace_attribute(owner: object, name: str, value: object) -> None:
    setattr(owner, name, value)


class _ControlStop(BaseException):
    pass


class _SinkBroke(BaseException):
    def __init__(self, error: BaseException) -> None:
        self.error = error


@dataclass(frozen=True, slots=True)
class RawTraceEvent:
    frame: types.FrameType
    event: str
    argument: object


@dataclass(frozen=True, slots=True)
class SnapshotRequest:
    frame: types.FrameType
    event: str
    value: object | None = None


@dataclass(slots=True)
class _FrameState:
    frame_id: int
    generator: bool
    suspended: bool = False
    pending_exception: BaseException | None = None


class _CapturedStream:
    def __init__(
        self,
        stream: StreamName,
        write_output: Callable[[StreamName, str], None],
    ) -> None:
        self._stream = stream
        self._write_output = write_output

    encoding = "utf-8"

    def writable(self) -> bool:
        return True

    def write(self, text: str) -> int:
        self._write_output(self._stream, text)
        return len(text)

    def flush(self) -> None:
        return None


class _RecordEmitter:
    def __init__(self, sink: TraceSink, options: TraceOptions) -> None:
        self._sink = sink
        self._budget = TraceBudget(options.max_record_bytes, options.max_trace_bytes)
        self.next_seq = 0
        self.step_count = 0
        self.diagnostic_count = 0
        self.sink_failure: BaseException | None = None

    @property
    def trace_bytes(self) -> int:
        return self._budget.trace_bytes

    def start(self, header: Record) -> None:
        try:
            payload = self._budget.admit_non_terminal(header)
        except (RecordLimitError, TraceLimitError) as error:
            raise ValueError("header cannot fit the configured record and trace budgets") from error
        self._deliver(header)
        assert payload
        self.next_seq = 1

    def emit_step(self, record: Record) -> None:
        self._budget.admit_non_terminal(record)
        self._deliver(record)
        self.next_seq += 1
        self.step_count += 1

    def emit_diagnostic(self, code: str, message: str) -> None:
        record: Record = {
            "kind": "diagnostic",
            "seq": self.next_seq,
            "severity": "warning",
            "code": code,
            "message": message,
            "at_step": self.step_count,
        }
        self._budget.admit_non_terminal(record)
        self._deliver(record)
        self.next_seq += 1
        self.diagnostic_count += 1

    def emit_terminal(
        self,
        reason: TerminalReason,
        *,
        stdout_bytes: int,
        stderr_bytes: int,
        exception: dict[str, Any] | None = None,
    ) -> RunSummary:
        record: Record = {
            "kind": "terminal",
            "seq": self.next_seq,
            "reason": reason,
            "synthetic": False,
            "trace_complete": True,
            "summary": {
                "step_count": self.step_count,
                "diagnostic_count": self.diagnostic_count,
                "stdout_bytes": stdout_bytes,
                "stderr_bytes": stderr_bytes,
                "trace_bytes": 1,
            },
        }
        if exception is not None:
            record["exception"] = exception
        finalized, _ = self._budget.finalize_terminal(record)
        self._deliver(finalized)
        summary = finalized["summary"]
        return RunSummary(
            run_id="",
            terminal_reason=reason,
            terminal_seq=self.next_seq,
            step_count=self.step_count,
            diagnostic_count=self.diagnostic_count,
            stdout_bytes=stdout_bytes,
            stderr_bytes=stderr_bytes,
            trace_bytes=summary["trace_bytes"],
            trace_complete=True,
        )

    def _deliver(self, record: Record) -> None:
        if self.sink_failure is not None:
            raise _SinkBroke(self.sink_failure)
        try:
            self._sink.emit(record)
        except BaseException as error:
            self.sink_failure = error
            raise _SinkBroke(error) from error


class _TraceController:
    def __init__(
        self,
        *,
        code: types.CodeType,
        globals_dict: dict[str, object],
        options: TraceOptions,
        emitter: _RecordEmitter,
        input_provider: InputProvider,
        interrupt_exceptions: tuple[type[BaseException], ...] = (),
        interrupt_requested: Callable[[], bool] | None = None,
    ) -> None:
        self.options = options
        self.emitter = emitter
        self.input_provider = input_provider
        self.interrupt_exceptions = interrupt_exceptions
        self.interrupt_requested = interrupt_requested
        self.main_globals = globals_dict
        self.identity = IdentityRegistry(options.identity_tombstones)
        self.frame_ids = FrameIdAllocator()
        self.active_invocations = ActiveInvocations()
        self.provenance = FunctionProvenanceResolver(
            LexicalParentMap.from_code(code), self.active_invocations
        )
        self.output = OutputAccumulator(options.max_output_bytes)
        self.states: dict[int, _FrameState] = {}
        self.module_globals: dict[str, dict[str, object]] = {"__main__": globals_dict}
        self.opnames: dict[int, tuple[types.CodeType, dict[int, str]]] = {}
        self.forced_reason: TerminalReason | None = None
        self.internal_error: BaseException | None = None
        self.degraded = False
        self._degradation_codes: set[str] = set()
        self._output_diagnostic_emitted = False
        self._hook_diagnostic_emitted = False
        self._input_request = 0
        self.expected_trace: object | None = None

    def trace(
        self,
        frame: types.FrameType,
        event: str,
        argument: object,
    ) -> Callable[..., object] | None:
        if self.forced_reason is not None:
            raise _ControlStop
        if self.interrupt_requested is not None and self.interrupt_requested():
            self._force("interrupted")
        if event == "call" and not self._qualifies(frame):
            return None
        if event != "call" and id(frame) not in self.states:
            return None
        try:
            request = self._normalize(RawTraceEvent(frame, event, argument))
            if request is not None:
                self._emit_snapshot(request)
        except _ControlStop, _SinkBroke:
            raise
        except BaseException as error:
            if type(error) in self.interrupt_exceptions:
                raise
            self.internal_error = error
            self.forced_reason = "engine_error"
            raise _ControlStop from error
        return self.trace

    def input(self, prompt: object = "") -> str:
        if self.forced_reason is not None:
            raise _ControlStop
        prompt_text = prompt if type(prompt) is str else str(prompt)
        self._write_output("stdout", prompt_text)
        self._input_request += 1
        request_id = f"input-{self._input_request}"
        frame = sys._getframe(1)
        self._emit_snapshot(
            SnapshotRequest(frame=frame, event="input", value=InputEvent(request_id, prompt_text))
        )
        try:
            line = self.input_provider.provide_input(request_id, prompt_text)
        except InputCancelled:
            self._force("interrupted")
        except BaseException as error:
            if type(error) in self.interrupt_exceptions:
                raise
            self.internal_error = error
            self._force("engine_error")
        if line is None:
            self._force("needs_input")
        if type(line) is not str:
            self.internal_error = TypeError("input provider must return an exact string or None")
            self._force("engine_error")
        line_value = cast(str, line)
        if "\n" in line_value or "\r" in line_value:
            self.internal_error = ValueError("input line must not contain a line terminator")
            self._force("engine_error")
        try:
            input_bytes = len(line_value.encode("utf-8"))
        except UnicodeEncodeError as error:
            self.internal_error = error
            self._force("engine_error")
        if input_bytes > self.options.max_input_line_bytes:
            self.internal_error = ValueError("input line exceeds max_input_line_bytes")
            self._force("engine_error")
        if self.options.echo_stdin:
            self._write_output("stdout", line_value + "\n")
        return line_value

    def mark_thread_use(self) -> None:
        if self.forced_reason is not None:
            raise _ControlStop
        self._mark_degraded("unsupported_thread", "additional thread use is unsupported")

    def mark_output_truncated(self) -> None:
        if self._output_diagnostic_emitted:
            return
        self._output_diagnostic_emitted = True
        try:
            self.emitter.emit_diagnostic(
                "output_truncated", "program output exceeded max_output_bytes"
            )
        except TraceLimitError:
            self._force("trace_limit")

    def _write_output(self, stream: StreamName, text: str) -> None:
        if self.forced_reason is not None:
            raise _ControlStop
        if self.expected_trace is not None and sys.gettrace() is not self.expected_trace:
            self._emit_hook_replacement_diagnostic()
            self._force("engine_error")
        was_truncated = self.output.output_truncated
        self.output.write(stream, text)
        if not was_truncated and self.output.output_truncated:
            self.mark_output_truncated()

    def _emit_hook_replacement_diagnostic(self) -> None:
        if self._hook_diagnostic_emitted:
            return
        self._hook_diagnostic_emitted = True
        try:
            self.emitter.emit_diagnostic("trace_hook_replaced", "user code replaced the trace hook")
        except TraceLimitError:
            return

    def _normalize(self, raw: RawTraceEvent) -> SnapshotRequest | None:
        frame = raw.frame
        raw_id = id(frame)
        state = self.states.get(raw_id)
        if raw.event == "call":
            if frame.f_code.co_flags & (inspect.CO_COROUTINE | inspect.CO_ASYNC_GENERATOR):
                self._mark_degraded(
                    "unsupported_coroutine", "coroutine and async-generator frames are unsupported"
                )
                return None
            if state is not None and state.suspended:
                state.suspended = False
                state.pending_exception = None
                return SnapshotRequest(frame, "resume")
            if state is None:
                state = _FrameState(
                    frame_id=self.frame_ids.allocate(),
                    generator=bool(frame.f_code.co_flags & inspect.CO_GENERATOR),
                )
                self.states[raw_id] = state
                self.active_invocations.register(frame.f_code, state.frame_id)
            self._remember_module(frame)
            return SnapshotRequest(frame, "call")
        if state is None:
            return None
        if raw.event == "line":
            state.pending_exception = None
            return SnapshotRequest(frame, "line")
        if raw.event == "exception":
            exception = self._exception_from_argument(raw.argument)
            state.pending_exception = exception
            return SnapshotRequest(frame, "exception", exception)
        if raw.event == "return":
            if state.generator and self._current_opname(frame).startswith("YIELD"):
                state.suspended = True
                state.pending_exception = None
                return SnapshotRequest(frame, "yield", raw.argument)
            event = "unwind" if state.pending_exception is not None else "return"
            value = state.pending_exception if event == "unwind" else raw.argument
            return SnapshotRequest(frame, event, value)
        return None

    def _emit_snapshot(self, request: SnapshotRequest) -> None:
        if self.emitter.step_count >= self.options.max_steps:
            self._force("step_limit")
        context = self._snapshot_context(request)
        try:
            record = encode_snapshot(
                context,
                self.options,
                identity_registry=self.identity,
                provenance_resolver=self.provenance,
            )
            self.emitter.emit_step(record)
        except RecordLimitError, TraceLimitError:
            self.identity.retain_visible_uids(set())
            self._force("trace_limit")
        if request.event in {"return", "unwind"}:
            self._retire_frame(request.frame)

    def _snapshot_context(self, request: SnapshotRequest) -> SnapshotContext:
        stack = self._stack(request.frame)
        globals_records = self._globals()
        event_data: ValueEvent | ExceptionEvent | InputEvent | None
        if request.event in {"yield", "return"}:
            event_data = ValueEvent(request.value)
        elif request.event in {"exception", "unwind"}:
            event_data = ExceptionEvent(cast(BaseException, request.value))
        elif request.event == "input":
            event_data = cast(InputEvent, request.value)
        else:
            event_data = None
        return SnapshotContext(
            seq=self.emitter.next_seq,
            step=self.emitter.step_count,
            event=cast(Any, request.event),
            location=self._location(request.frame),
            stack=stack,
            globals=globals_records,
            output=self.output.take_delta(),
            event_data=event_data,
            output_truncated=self.output.output_truncated,
            degraded=self.degraded,
        )

    def _stack(self, active: types.FrameType) -> tuple[SnapshotFrame, ...]:
        frames: list[types.FrameType] = []
        current: types.FrameType | None = active
        while current is not None:
            if self._qualifies(current):
                frames.append(current)
            current = current.f_back
        frames.reverse()
        snapshots: list[SnapshotFrame] = []
        for frame in frames:
            state = self.states.get(id(frame))
            if state is None:
                state = _FrameState(
                    self.frame_ids.allocate(),
                    bool(frame.f_code.co_flags & inspect.CO_GENERATOR),
                )
                self.states[id(frame)] = state
                self.active_invocations.register(frame.f_code, state.frame_id)
            snapshots.append(
                SnapshotFrame(
                    frame_id=state.frame_id,
                    function=frame.f_code.co_name,
                    module=self._module_name(frame),
                    location=self._location(frame),
                    locals=self._bindings(frame.f_locals, frame.f_globals is self.main_globals),
                )
            )
        return tuple(snapshots)

    def _globals(self) -> tuple[SnapshotGlobals, ...]:
        scopes = [SnapshotGlobals("__main__", self._bindings(self.main_globals, True))]
        for module_name in self.options.trace_modules:
            namespace = self.module_globals.get(module_name)
            if namespace is None:
                module = sys.modules.get(module_name)
                namespace = vars(module) if type(module) is types.ModuleType else {}
            scopes.append(SnapshotGlobals(module_name, self._bindings(namespace, True)))
        return tuple(scopes)

    @staticmethod
    def _bindings(
        namespace: dict[str, object],
        hide_module_internals: bool,
    ) -> tuple[tuple[str, object], ...]:
        return tuple(
            (name, value)
            for name, value in namespace.items()
            if type(name) is str
            and (not hide_module_internals or name not in _MODULE_INTERNAL_NAMES)
        )

    def _mark_degraded(self, code: str, message: str) -> None:
        self.degraded = True
        if code in self._degradation_codes:
            return
        self._degradation_codes.add(code)
        try:
            self.emitter.emit_diagnostic(code, message)
        except TraceLimitError:
            self._force("trace_limit")

    def _force(self, reason: TerminalReason) -> None:
        if self.forced_reason is None:
            self.forced_reason = reason
        raise _ControlStop

    def _qualifies(self, frame: types.FrameType) -> bool:
        if frame.f_globals is self.main_globals:
            return True
        return self._module_name(frame) in self.options.trace_modules

    def _remember_module(self, frame: types.FrameType) -> None:
        name = self._module_name(frame)
        if name in self.options.trace_modules:
            self.module_globals[name] = frame.f_globals

    @staticmethod
    def _module_name(frame: types.FrameType) -> str:
        name = frame.f_globals.get("__name__")
        return name if type(name) is str else ""

    @staticmethod
    def _location(frame: types.FrameType) -> SnapshotLocation:
        return SnapshotLocation(
            filename=frame.f_code.co_filename,
            module=_TraceController._module_name(frame),
            function=frame.f_code.co_name,
            line=max(frame.f_lineno, 1),
        )

    def _current_opname(self, frame: types.FrameType) -> str:
        raw_id = id(frame.f_code)
        entry = self.opnames.get(raw_id)
        if entry is None or entry[0] is not frame.f_code:
            entry = (
                frame.f_code,
                {
                    instruction.offset: instruction.opname
                    for instruction in dis.get_instructions(frame.f_code)
                },
            )
            self.opnames[raw_id] = entry
        return entry[1].get(frame.f_lasti, "")

    @staticmethod
    def _exception_from_argument(argument: object) -> BaseException:
        if type(argument) is not tuple or len(argument) != 3:
            raise RuntimeError("invalid CPython exception trace argument")
        exception = argument[1]
        exception_type = type(exception)
        if BaseException not in type.__getattribute__(exception_type, "__mro__"):
            raise RuntimeError("trace exception argument has no exception instance")
        return cast(BaseException, exception)

    def _retire_frame(self, frame: types.FrameType) -> None:
        state = self.states.pop(id(frame), None)
        if state is not None:
            self.active_invocations.unregister(frame.f_code, state.frame_id)


def _run_with_host(
    source: str,
    *,
    run_id: str,
    options: TraceOptions,
    sink: TraceSink,
    input_provider: InputProvider,
    host_info: dict[str, Any] | None = None,
    interrupt_exceptions: tuple[type[BaseException], ...] = (),
    host_diagnostics: tuple[tuple[str, str], ...] = (),
    interrupt_requested: Callable[[], bool] | None = None,
) -> RunSummary:
    """Execute trusted source once in the current interpreter."""

    if sys.gettrace() is not None:
        raise TraceConflictError("an unrelated trace function is already active")
    if type(source) is not str:
        raise ValueError("source must be an exact string")
    if type(run_id) is not str or not run_id:
        raise ValueError("run_id must be a non-empty exact string")
    try:
        source_bytes = source.encode("utf-8")
    except UnicodeEncodeError as error:
        raise ValueError("source must be valid UTF-8") from error
    if len(source_bytes) > options.max_source_bytes:
        raise ValueError("source exceeds max_source_bytes")
    input_mode = input_provider.input_mode
    if input_mode not in {"live", "pre_supplied"}:
        raise ValueError("input provider has an invalid input_mode")

    syntax_error: SyntaxError | None = None
    try:
        code = compile(source, _SYNTHETIC_FILENAME, "exec", dont_inherit=True)
    except SyntaxError as error:
        syntax_error = error
        code = compile("", _SYNTHETIC_FILENAME, "exec", dont_inherit=True)

    globals_dict: dict[str, object] = {"__name__": "__main__"}
    emitter = _RecordEmitter(sink, options)
    try:
        emitter.start(_header(run_id, source, source_bytes, options, input_mode, host_info))
    except _SinkBroke as failure:
        raise failure.error from None
    for diagnostic_code, diagnostic_message in host_diagnostics:
        try:
            emitter.emit_diagnostic(diagnostic_code, diagnostic_message)
        except _SinkBroke as failure:
            raise failure.error from None
        except RecordLimitError, TraceLimitError:
            summary = _emit_terminal_or_raise(
                emitter,
                "trace_limit",
                stdout_bytes=0,
                stderr_bytes=0,
            )
            return _with_run_id(summary, run_id)
    if interrupt_requested is not None and interrupt_requested():
        summary = _emit_terminal_or_raise(
            emitter,
            "interrupted",
            stdout_bytes=0,
            stderr_bytes=0,
        )
        return _with_run_id(summary, run_id)
    if syntax_error is not None:
        summary = _emit_terminal_or_raise(
            emitter,
            "uncaught_exception",
            stdout_bytes=0,
            stderr_bytes=0,
            exception=_exception_summary(syntax_error),
        )
        return _with_run_id(summary, run_id)

    controller = _TraceController(
        code=code,
        globals_dict=globals_dict,
        options=options,
        emitter=emitter,
        input_provider=input_provider,
        interrupt_exceptions=interrupt_exceptions,
        interrupt_requested=interrupt_requested,
    )
    stdout = _CapturedStream("stdout", controller._write_output)
    stderr = _CapturedStream("stderr", controller._write_output)
    trace_callback = controller.trace
    controller.expected_trace = trace_callback
    original_stdout = sys.stdout
    original_stderr = sys.stderr
    original_input = builtins.input
    original_thread_start = threading.Thread.start
    original_settrace = sys.settrace
    original_cwd = os.getcwd()
    original_argv = sys.argv
    original_argv_values = list(sys.argv)
    original_path = sys.path
    original_path_values = list(sys.path)
    original_recursion_limit = sys.getrecursionlimit()
    original_warning_filters = cast(list[Any], warnings.filters)
    original_warning_filter_values = list(warnings.filters)
    original_warning_default = warnings.__dict__["defaultaction"]
    original_warning_registry = cast(dict[object, object], warnings.__dict__["onceregistry"])
    original_warning_registry_values = dict(original_warning_registry)
    original_showwarning = warnings.showwarning
    source_exception: BaseException | None = None
    sink_failure: BaseException | None = None
    controlled_stop = False

    def thread_start(thread: threading.Thread) -> None:
        controller.mark_thread_use()
        original_thread_start(thread)

    try:
        sys.stdout = cast(TextIO, stdout)
        sys.stderr = cast(TextIO, stderr)
        builtins.input = controller.input
        _replace_attribute(threading.Thread, "start", thread_start)
        original_settrace(cast(Any, trace_callback))
        try:
            exec(code, globals_dict)
        except _SinkBroke as failure:
            sink_failure = failure.error
        except _ControlStop:
            controlled_stop = True
        except BaseException as error:
            source_exception = error
    finally:
        hook_replaced = (
            not controlled_stop
            and controller.forced_reason is None
            and not (interrupt_requested is not None and interrupt_requested())
            and not (
                source_exception is not None and type(source_exception) in interrupt_exceptions
            )
            and (sys.gettrace() is not trace_callback or sys.settrace is not original_settrace)
        )
        original_settrace(None)
        _replace_attribute(sys, "settrace", original_settrace)
        _replace_attribute(threading.Thread, "start", original_thread_start)
        builtins.input = original_input
        sys.stdout = original_stdout
        sys.stderr = original_stderr
        os.chdir(original_cwd)
        original_argv[:] = original_argv_values
        _replace_attribute(sys, "argv", original_argv)
        original_path[:] = original_path_values
        _replace_attribute(sys, "path", original_path)
        sys.setrecursionlimit(original_recursion_limit)
        original_warning_filters[:] = original_warning_filter_values
        _replace_attribute(warnings, "filters", original_warning_filters)
        _replace_attribute(warnings, "defaultaction", original_warning_default)
        original_warning_registry.clear()
        original_warning_registry.update(original_warning_registry_values)
        _replace_attribute(warnings, "onceregistry", original_warning_registry)
        _replace_attribute(warnings, "showwarning", original_showwarning)

    if sink_failure is None:
        sink_failure = emitter.sink_failure
    if sink_failure is not None:
        raise sink_failure
    if hook_replaced:
        controller._emit_hook_replacement_diagnostic()
        controller.forced_reason = "engine_error"
    reason: TerminalReason
    terminal_exception: dict[str, Any] | None = None
    if interrupt_requested is not None and interrupt_requested():
        reason = "interrupted"
    elif controller.forced_reason is not None:
        reason = controller.forced_reason
    elif controller.internal_error is not None:
        reason = "engine_error"
    elif source_exception is not None and type(source_exception) in interrupt_exceptions:
        reason = "interrupted"
    elif source_exception is not None:
        reason = "uncaught_exception"
        terminal_exception = _exception_summary(source_exception)
    else:
        reason = "completed"
    summary = _emit_terminal_or_raise(
        emitter,
        reason,
        stdout_bytes=controller.output.stdout_bytes,
        stderr_bytes=controller.output.stderr_bytes,
        exception=terminal_exception,
    )
    return _with_run_id(summary, run_id)


def run_in_process(
    source: str,
    *,
    run_id: str,
    options: TraceOptions,
    sink: TraceSink,
    input_provider: InputProvider,
) -> RunSummary:
    """Execute trusted source once in the current interpreter."""

    return _run_with_host(
        source,
        run_id=run_id,
        options=options,
        sink=sink,
        input_provider=input_provider,
    )


def collect_trace(
    source: str,
    *,
    run_id: str = "run",
    options: TraceOptions | None = None,
    stdin_lines: Iterable[str] = (),
) -> list[Record]:
    """Run trusted source and return all emitted records in memory."""

    sink = ListTraceSink()
    run_in_process(
        source,
        run_id=run_id,
        options=options or TraceOptions(),
        sink=sink,
        input_provider=QueueInputProvider(stdin_lines),
    )
    return sink.records


def _header(
    run_id: str,
    source: str,
    source_bytes: bytes,
    options: TraceOptions,
    input_mode: str,
    host_info: dict[str, Any] | None,
) -> Record:
    host_platform = {"darwin": "macos", "linux": "linux"}.get(sys.platform)
    if host_info is None and host_platform is None:
        raise ValueError("in-process tracing supports only Linux and macOS")
    live_input = input_mode == "live"
    return {
        "kind": "header",
        "seq": 0,
        "format": "trace-engine/1",
        "run_id": run_id,
        "engine_version": _ENGINE_VERSION,
        "python_version": platform.python_version(),
        "backend": "settrace",
        "source": source,
        "source_sha256": hashlib.sha256(source_bytes).hexdigest(),
        "options": options.to_record(),
        "host": host_info
        or {
            "kind": "in_process",
            "runtime": "cpython",
            "platform": host_platform,
            "input_mode": input_mode,
            "python_hash_seed": "uncontrolled",
            "capabilities": {
                "live_input": live_input,
                "cooperative_interrupt": False,
                "hard_interrupt": False,
                "process_group": False,
                "cpu_limit": False,
                "address_space_limit": False,
                "cross_origin_isolated": False,
            },
        },
    }


def _exception_summary(error: BaseException) -> dict[str, Any]:
    error_type = type(error)
    type_name = type.__getattribute__(error_type, "__name__")
    summary: dict[str, Any] = {"type_name": type_name}
    if error_type is SyntaxError:
        message = object.__getattribute__(error, "msg")
        if type(message) is str:
            summary["safe_message"] = message
        filename = object.__getattribute__(error, "filename")
        line = object.__getattribute__(error, "lineno")
        if type(filename) is str and type(line) is int and line >= 1:
            summary["location"] = {
                "filename": filename,
                "module": "__main__",
                "function": "<module>",
                "line": line,
            }
    return summary


def _with_run_id(summary: RunSummary, run_id: str) -> RunSummary:
    return RunSummary(
        run_id=run_id,
        terminal_reason=summary.terminal_reason,
        terminal_seq=summary.terminal_seq,
        step_count=summary.step_count,
        diagnostic_count=summary.diagnostic_count,
        stdout_bytes=summary.stdout_bytes,
        stderr_bytes=summary.stderr_bytes,
        trace_bytes=summary.trace_bytes,
        trace_complete=summary.trace_complete,
    )


def _emit_terminal_or_raise(
    emitter: _RecordEmitter,
    reason: TerminalReason,
    *,
    stdout_bytes: int,
    stderr_bytes: int,
    exception: dict[str, Any] | None = None,
) -> RunSummary:
    try:
        return emitter.emit_terminal(
            reason,
            stdout_bytes=stdout_bytes,
            stderr_bytes=stderr_bytes,
            exception=exception,
        )
    except _SinkBroke as failure:
        raise failure.error from None

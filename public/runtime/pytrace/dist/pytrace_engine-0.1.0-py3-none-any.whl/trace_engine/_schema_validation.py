"""Dependency-free validation against the packaged canonical record schema."""

from __future__ import annotations

import json
import math
import re
from functools import cache
from importlib import resources
from pathlib import Path
from typing import Any, cast

from .records import Record


class RecordSchemaError(ValueError):
    """Raised when a record does not satisfy the canonical JSON Schema."""


class _SchemaMismatch(Exception):
    pass


@cache
def _canonical_schema() -> dict[str, Any]:
    packaged = resources.files("trace_engine").joinpath("trace-engine-1.schema.json")
    try:
        text = packaged.read_text(encoding="utf-8")
    except FileNotFoundError:
        source_tree = Path(__file__).resolve().parents[2] / "schema" / "trace-engine-1.schema.json"
        text = source_tree.read_text(encoding="utf-8")
    value = json.loads(text)
    if type(value) is not dict:
        raise RuntimeError("canonical record schema must be an object")
    return value


def validate_record_schema(record: Record) -> None:
    """Validate one exact-JSON record against the canonical Draft 2020-12 schema."""

    schema = _canonical_schema()
    try:
        _validate(record, schema, schema)
    except _SchemaMismatch as error:
        raise RecordSchemaError("record does not satisfy the canonical JSON Schema") from error


def _validate(instance: object, schema: object, root: dict[str, Any]) -> None:
    if schema is True:
        return
    if schema is False or type(schema) is not dict:
        raise _SchemaMismatch

    reference = schema.get("$ref")
    if reference is not None:
        if type(reference) is not str:
            raise _SchemaMismatch
        _validate(instance, _resolve_reference(reference, root), root)

    expected_type = schema.get("type")
    if expected_type is not None and not _has_json_type(instance, expected_type):
        raise _SchemaMismatch

    if "const" in schema and not _json_equal(instance, schema["const"]):
        raise _SchemaMismatch
    choices = schema.get("enum")
    if choices is not None and (
        type(choices) is not list or not any(_json_equal(instance, choice) for choice in choices)
    ):
        raise _SchemaMismatch

    one_of = schema.get("oneOf")
    if one_of is not None and (
        type(one_of) is not list or sum(_matches(instance, branch, root) for branch in one_of) != 1
    ):
        raise _SchemaMismatch
    all_of = schema.get("allOf")
    if all_of is not None:
        if type(all_of) is not list:
            raise _SchemaMismatch
        for branch in all_of:
            _validate(instance, branch, root)
    if "not" in schema and _matches(instance, schema["not"], root):
        raise _SchemaMismatch
    if_schema = schema.get("if")
    if if_schema is not None:
        branch = schema.get("then") if _matches(instance, if_schema, root) else schema.get("else")
        if branch is not None:
            _validate(instance, branch, root)

    if type(instance) is dict:
        _validate_object(instance, schema, root)
    elif type(instance) is list:
        _validate_array(instance, schema, root)
    elif type(instance) is str:
        _validate_string(instance, schema)
    elif _is_json_number(instance):
        _validate_number(cast(int | float, instance), schema)


def _validate_object(
    instance: dict[object, object],
    schema: dict[str, Any],
    root: dict[str, Any],
) -> None:
    required = schema.get("required", [])
    if type(required) is not list or any(name not in instance for name in required):
        raise _SchemaMismatch
    properties = schema.get("properties", {})
    if type(properties) is not dict:
        raise _SchemaMismatch
    for name, subschema in properties.items():
        if name in instance:
            _validate(instance[name], subschema, root)
    if schema.get("additionalProperties") is False and any(
        name not in properties for name in instance
    ):
        raise _SchemaMismatch


def _validate_array(
    instance: list[object],
    schema: dict[str, Any],
    root: dict[str, Any],
) -> None:
    minimum = schema.get("minItems")
    if minimum is not None and (type(minimum) is not int or len(instance) < minimum):
        raise _SchemaMismatch
    if schema.get("uniqueItems") is True:
        for index, value in enumerate(instance):
            if any(_json_equal(value, other) for other in instance[index + 1 :]):
                raise _SchemaMismatch
    if "items" in schema:
        for value in instance:
            _validate(value, schema["items"], root)


def _validate_string(instance: str, schema: dict[str, Any]) -> None:
    minimum = schema.get("minLength")
    if minimum is not None and (type(minimum) is not int or len(instance) < minimum):
        raise _SchemaMismatch
    pattern = schema.get("pattern")
    if pattern is not None and (type(pattern) is not str or re.search(pattern, instance) is None):
        raise _SchemaMismatch


def _validate_number(instance: int | float, schema: dict[str, Any]) -> None:
    minimum = schema.get("minimum")
    if minimum is not None and instance < minimum:
        raise _SchemaMismatch
    exclusive_minimum = schema.get("exclusiveMinimum")
    if exclusive_minimum is not None and instance <= exclusive_minimum:
        raise _SchemaMismatch


def _resolve_reference(reference: str, root: dict[str, Any]) -> object:
    if not reference.startswith("#/"):
        raise _SchemaMismatch
    current: object = root
    for raw_part in reference[2:].split("/"):
        part = raw_part.replace("~1", "/").replace("~0", "~")
        if type(current) is not dict or part not in current:
            raise _SchemaMismatch
        current = current[part]
    return current


def _matches(instance: object, schema: object, root: dict[str, Any]) -> bool:
    try:
        _validate(instance, schema, root)
    except _SchemaMismatch:
        return False
    return True


def _has_json_type(instance: object, expected: object) -> bool:
    if type(expected) is list:
        return any(_has_json_type(instance, candidate) for candidate in expected)
    if type(expected) is not str:
        return False
    return {
        "object": type(instance) is dict,
        "array": type(instance) is list,
        "string": type(instance) is str,
        "boolean": type(instance) is bool,
        "integer": type(instance) is int,
        "number": _is_json_number(instance),
        "null": instance is None,
    }.get(expected, False)


def _is_json_number(value: object) -> bool:
    return type(value) is int or (type(value) is float and math.isfinite(value))


def _json_equal(left: object, right: object) -> bool:
    if _is_json_number(left) and _is_json_number(right):
        return left == right
    if type(left) is not type(right):
        return False
    if type(left) is dict:
        left_mapping = cast(dict[object, object], left)
        right_mapping = cast(dict[object, object], right)
        if set(left_mapping) != set(right_mapping):
            return False
        return all(_json_equal(left_mapping[name], right_mapping[name]) for name in left_mapping)
    if type(left) is list:
        left_values = cast(list[object], left)
        right_values = cast(list[object], right)
        return len(left_values) == len(right_values) and all(
            _json_equal(left_item, right_item)
            for left_item, right_item in zip(left_values, right_values, strict=True)
        )
    return left == right

"""Dependency-free cross-record validation for canonical trace streams."""

from __future__ import annotations

import base64
import binascii
import hashlib
from collections.abc import Iterable, Sequence
from typing import Final

from ._schema_validation import RecordSchemaError, validate_record_schema
from .output import normalize_output_text
from .records import JSONValue, Record
from .serialization import canonical_record_bytes

_TOP_LEVEL_KEYS: Final = {
    "header": {
        "kind",
        "seq",
        "format",
        "run_id",
        "engine_version",
        "python_version",
        "backend",
        "source",
        "source_sha256",
        "options",
        "host",
    },
    "step": {
        "kind",
        "seq",
        "step",
        "event",
        "location",
        "stack",
        "globals",
        "closure_environments",
        "heap",
        "output",
        "flags",
        "event_data",
    },
    "diagnostic": {"kind", "seq", "severity", "code", "message", "at_step", "details"},
    "terminal": {
        "kind",
        "seq",
        "reason",
        "synthetic",
        "trace_complete",
        "summary",
        "exception",
    },
}
_REQUIRED_TOP_LEVEL_KEYS: Final = {
    "header": _TOP_LEVEL_KEYS["header"],
    "step": _TOP_LEVEL_KEYS["step"] - {"event_data"},
    "diagnostic": {"kind", "seq", "severity", "code", "message"},
    "terminal": {"kind", "seq", "reason", "synthetic", "trace_complete", "summary"},
}
_STEP_EVENTS: Final = {
    "call",
    "resume",
    "line",
    "yield",
    "return",
    "exception",
    "unwind",
    "input",
}
_TERMINAL_REASONS: Final = {
    "completed",
    "uncaught_exception",
    "step_limit",
    "trace_limit",
    "needs_input",
    "interrupted",
    "killed",
    "engine_error",
}
_REFERENCE_FREE_SCALARS: Final = {
    "none",
    "bool",
    "int",
    "float",
    "str",
    "bytes",
    "complex",
    "range",
    "slice",
    "ellipsis",
    "not_implemented",
}


class StreamValidationError(ValueError):
    """Raised when records violate the canonical stream contract."""


class _StreamValidator:
    """Validate one canonical stream incrementally without third-party dependencies."""

    def __init__(self) -> None:
        self.expected_seq = 0
        self.step_count = 0
        self.diagnostic_count = 0
        self.stdout_bytes = 0
        self.stderr_bytes = 0
        self.trace_bytes = 0
        self.trace_modules: list[JSONValue] | None = None
        self.terminal_seen = False

    def accept(self, record: Record) -> None:
        if self.terminal_seen:
            raise StreamValidationError("stream contains a record after terminal")
        _validate_top_level(record)
        payload = canonical_record_bytes(record)
        if type(record.get("seq")) is not int or record["seq"] != self.expected_seq:
            raise StreamValidationError("record seq values must be contiguous")
        kind = record.get("kind")
        next_stdout = self.stdout_bytes
        next_stderr = self.stderr_bytes
        next_step_count = self.step_count
        next_diagnostic_count = self.diagnostic_count
        next_trace_modules = self.trace_modules
        terminal_seen = False

        if self.expected_seq == 0:
            if kind != "header":
                raise StreamValidationError("stream must begin with header seq 0")
            next_trace_modules = _validate_header(record)
        elif kind == "header":
            raise StreamValidationError("stream must contain exactly one header")
        elif self.trace_modules is None:
            raise StreamValidationError("stream header state is missing")

        if kind == "step":
            if type(record.get("step")) is not int or record["step"] != self.step_count:
                raise StreamValidationError("step values must be contiguous")
            next_stdout, next_stderr = _validate_step(
                record,
                stdout_bytes=self.stdout_bytes,
                stderr_bytes=self.stderr_bytes,
                trace_modules=self.trace_modules or [],
            )
            next_step_count += 1
        elif kind == "diagnostic":
            _validate_diagnostic(record, step_count=self.step_count)
            next_diagnostic_count += 1
        elif kind == "terminal":
            _validate_terminal_combination(record)
            _validate_terminal_summary(
                record,
                step_count=self.step_count,
                diagnostic_count=self.diagnostic_count,
                stdout_bytes=self.stdout_bytes,
                stderr_bytes=self.stderr_bytes,
                trace_bytes=self.trace_bytes + len(payload),
            )
            terminal_seen = True

        try:
            validate_record_schema(record)
        except RecordSchemaError as error:
            raise StreamValidationError("record violates the canonical JSON Schema") from error
        self.expected_seq += 1
        self.step_count = next_step_count
        self.diagnostic_count = next_diagnostic_count
        self.stdout_bytes = next_stdout
        self.stderr_bytes = next_stderr
        self.trace_bytes += len(payload)
        self.trace_modules = next_trace_modules
        self.terminal_seen = terminal_seen

    def finish(self) -> None:
        if self.expected_seq == 0:
            raise StreamValidationError("stream is empty")
        if not self.terminal_seen:
            raise StreamValidationError("stream must end with one terminal")


def validate_stream_semantics(records: Sequence[Record]) -> None:
    """Validate cross-record semantics after per-record JSON Schema validation."""

    validator = _StreamValidator()
    for record in records:
        validator.accept(record)
    validator.finish()


def _validate_header(header: Record) -> list[JSONValue]:
    for name in (
        "format",
        "run_id",
        "engine_version",
        "python_version",
        "backend",
        "source",
        "source_sha256",
    ):
        _require_str(header, name)
    if header.get("format") != "trace-engine/1" or header.get("backend") != "settrace":
        raise StreamValidationError("header format or backend is invalid")
    source = _require_str(header, "source")
    expected_digest = hashlib.sha256(source.encode("utf-8")).hexdigest()
    if header.get("source_sha256") != expected_digest:
        raise StreamValidationError("header source_sha256 mismatch")
    options = _require_dict(header, "options")
    trace_modules = options.get("trace_modules")
    if not isinstance(trace_modules, list) or not all(
        type(module) is str for module in trace_modules
    ):
        raise StreamValidationError("header trace_modules must be a string array")
    _require_dict(header, "host")
    return trace_modules


def _validate_diagnostic(record: Record, *, step_count: int) -> None:
    if record.get("severity") not in {"warning", "error"}:
        raise StreamValidationError("diagnostic severity is invalid")
    code = _require_str(record, "code")
    if not code:
        raise StreamValidationError("diagnostic code must not be empty")
    _require_str(record, "message")
    at_step = record.get("at_step")
    if "at_step" in record and (type(at_step) is not int or at_step < 0 or at_step > step_count):
        raise StreamValidationError("diagnostic at_step is invalid")
    if "details" in record:
        _require_dict(record, "details")


def _validate_terminal_summary(
    terminal: Record,
    *,
    step_count: int,
    diagnostic_count: int,
    stdout_bytes: int,
    stderr_bytes: int,
    trace_bytes: int,
) -> None:
    summary = _require_dict(terminal, "summary")
    expected_summary = {
        "step_count": step_count,
        "diagnostic_count": diagnostic_count,
        "stdout_bytes": stdout_bytes,
        "stderr_bytes": stderr_bytes,
        "trace_bytes": trace_bytes,
    }
    for name, expected in expected_summary.items():
        if type(summary.get(name)) is not int or summary[name] != expected:
            raise StreamValidationError(f"terminal summary {name} mismatch")
    if "exception" in terminal:
        exception = _require_dict(terminal, "exception")
        if not _require_str(exception, "type_name"):
            raise StreamValidationError("terminal exception type_name must not be empty")


def _validate_top_level(record: Record) -> None:
    kind = record.get("kind")
    if kind not in _TOP_LEVEL_KEYS:
        raise StreamValidationError("unknown record kind")
    assert isinstance(kind, str)
    keys = set(record)
    if not _REQUIRED_TOP_LEVEL_KEYS[kind] <= keys:
        raise StreamValidationError(f"{kind} record is missing required fields")
    if not keys <= _TOP_LEVEL_KEYS[kind]:
        raise StreamValidationError(f"{kind} record contains unknown fields")
    if kind == "step":
        _validate_event_combination(record)


def _validate_event_combination(record: Record) -> None:
    event = record.get("event")
    if event not in _STEP_EVENTS:
        raise StreamValidationError("unknown step event")
    event_data = record.get("event_data")
    if event in {"call", "resume", "line"}:
        if "event_data" in record:
            raise StreamValidationError(f"{event} must not have event_data")
        return
    if not isinstance(event_data, dict):
        raise StreamValidationError(f"{event} requires event_data")
    expected = {
        "yield": "value",
        "return": "value",
        "exception": "exception",
        "unwind": "exception",
        "input": "input",
    }[event]
    if event_data.get("kind") != expected:
        raise StreamValidationError(f"{event} has incompatible event_data")


def _validate_step(
    record: Record,
    *,
    stdout_bytes: int,
    stderr_bytes: int,
    trace_modules: list[JSONValue],
) -> tuple[int, int]:
    heap = _require_list(record, "heap")
    heap_nodes = [_require_object(value, "heap node") for value in heap]
    heap_uids = [_require_positive_int(node, "uid") for node in heap_nodes]
    if len(set(heap_uids)) != len(heap_uids):
        raise StreamValidationError("heap UIDs must be unique within a step")

    stack = _require_list(record, "stack")
    if not stack:
        raise StreamValidationError("step stack must not be empty")
    frames = [_require_object(value, "frame") for value in stack]
    frame_ids = [_require_positive_int(frame, "frame_id") for frame in frames]
    if len(set(frame_ids)) != len(frame_ids):
        raise StreamValidationError("frame IDs must be unique within a step")

    globals_records = _require_list(record, "globals")
    modules = [
        _require_str(_require_object(value, "global scope"), "module") for value in globals_records
    ]
    expected_modules = ["__main__", *trace_modules]
    if modules != expected_modules:
        raise StreamValidationError("global scopes do not match trace_modules order")

    for frame in frames:
        _validate_unique_bindings(_require_list(frame, "locals"))
    for scope_value in globals_records:
        scope = _require_object(scope_value, "global scope")
        _validate_unique_bindings(_require_list(scope, "bindings"))

    environments = [
        _require_object(value, "closure environment")
        for value in _require_list(record, "closure_environments")
    ]
    environment_ids = [
        _require_positive_int(environment, "environment_id") for environment in environments
    ]
    if len(set(environment_ids)) != len(environment_ids):
        raise StreamValidationError("closure environment IDs must be unique")

    uid_set = set(heap_uids)
    references = _referenced_uids(record)
    if not references <= uid_set:
        raise StreamValidationError("step contains a dangling REF")

    node_by_uid = dict(zip(heap_uids, heap_nodes, strict=True))
    for environment in environments:
        for binding_value in _require_list(environment, "cells"):
            binding = _require_object(binding_value, "closure cell binding")
            value = _require_dict(binding, "value")
            if value.get("kind") != "ref":
                raise StreamValidationError("closure cells must reference cell nodes")
            uid = _require_positive_int(value, "uid")
            if node_by_uid[uid].get("kind") != "cell":
                raise StreamValidationError("closure cell reference must resolve to a cell node")
    _validate_function_links(heap_nodes, set(frame_ids), set(environment_ids))
    _validate_bytes_values(record)
    _validate_set_nodes(heap_nodes)

    output = _require_dict(record, "output")
    stdout_delta = normalize_output_text(_require_str(output, "stdout_delta"))
    stderr_delta = normalize_output_text(_require_str(output, "stderr_delta"))
    expected_stdout = stdout_bytes + len(stdout_delta.encode("utf-8"))
    expected_stderr = stderr_bytes + len(stderr_delta.encode("utf-8"))
    if output.get("stdout_bytes") != expected_stdout:
        raise StreamValidationError("stdout offset mismatch")
    if output.get("stderr_bytes") != expected_stderr:
        raise StreamValidationError("stderr offset mismatch")
    return expected_stdout, expected_stderr


def _validate_function_links(
    heap_nodes: list[dict[str, JSONValue]],
    frame_ids: set[int],
    environment_ids: set[int],
) -> None:
    for node in heap_nodes:
        if node.get("kind") != "function":
            continue
        provenance = node.get("provenance")
        if provenance == "resolved":
            if node.get("defining_frame_id") not in frame_ids:
                raise StreamValidationError("resolved function has invalid defining frame")
        elif provenance == "unknown":
            if "defining_frame_id" in node:
                raise StreamValidationError("unknown function claims a defining frame")
        else:
            raise StreamValidationError("function has invalid provenance")
        environment_id = node.get("closure_environment_id")
        if environment_id is not None and environment_id not in environment_ids:
            raise StreamValidationError("function has invalid closure environment")


def _validate_bytes_values(record: Record) -> None:
    for value in _walk_objects(record):
        if value.get("kind") != "bytes":
            continue
        text = value.get("base64")
        length = value.get("length")
        if type(text) is not str or type(length) is not int or length < 0:
            raise StreamValidationError("invalid bytes value")
        try:
            decoded = base64.b64decode(text, validate=True)
        except (binascii.Error, ValueError) as error:
            raise StreamValidationError("bytes value is not canonical base64") from error
        if base64.b64encode(decoded).decode("ascii") != text or len(decoded) != length:
            raise StreamValidationError("bytes value length or base64 mismatch")


def _validate_set_nodes(heap_nodes: list[dict[str, JSONValue]]) -> None:
    for node in heap_nodes:
        if node.get("kind") not in {"set", "frozenset"}:
            continue
        items = _require_list(node, "items")
        elided_count = node.get("elided_count")
        canonical_allowed = elided_count == 0 and all(
            _is_reference_free_scalar(item) for item in items
        )
        expected_ordering = "canonical" if canonical_allowed else "unordered"
        if node.get("ordering") != expected_ordering:
            raise StreamValidationError("set ordering declaration is invalid")
        if canonical_allowed:
            payloads = [canonical_record_bytes(_require_object(item, "set item")) for item in items]
            if payloads != sorted(payloads):
                raise StreamValidationError("canonical set items are not sorted")


def _is_reference_free_scalar(value: JSONValue) -> bool:
    if not isinstance(value, dict) or value.get("kind") not in _REFERENCE_FREE_SCALARS:
        return False
    if value.get("kind") == "slice":
        return all(_is_reference_free_scalar(value.get(name)) for name in ("start", "stop", "step"))
    return not any(nested.get("kind") in {"ref", "elided"} for nested in _walk_objects(value))


def _validate_unique_bindings(values: list[JSONValue]) -> None:
    names = [_require_str(_require_object(value, "binding"), "name") for value in values]
    if len(set(names)) != len(names):
        raise StreamValidationError("binding names must be unique")


def _validate_terminal_combination(terminal: Record) -> None:
    reason = terminal.get("reason")
    synthetic = terminal.get("synthetic")
    complete = terminal.get("trace_complete")
    if reason not in _TERMINAL_REASONS:
        raise StreamValidationError("unknown terminal reason")
    if reason == "killed":
        valid = synthetic is True and complete is False
    elif reason == "engine_error":
        valid = (synthetic is False and complete is True) or (
            synthetic is True and complete is False
        )
    else:
        valid = synthetic is False and complete is True
    if not valid:
        raise StreamValidationError("invalid terminal synthesis/completeness combination")
    has_exception = "exception" in terminal
    if (reason == "uncaught_exception") != has_exception:
        raise StreamValidationError("terminal exception field does not match reason")


def _referenced_uids(value: JSONValue) -> set[int]:
    result: set[int] = set()
    for nested in _walk_objects(value):
        if nested.get("kind") == "ref":
            result.add(_require_positive_int(nested, "uid"))
    return result


def _walk_objects(value: JSONValue) -> Iterable[dict[str, JSONValue]]:
    stack: list[JSONValue] = [value]
    while stack:
        current = stack.pop()
        if isinstance(current, dict):
            yield current
            stack.extend(current.values())
        elif isinstance(current, list):
            stack.extend(current)


def _require_object(value: JSONValue, description: str) -> dict[str, JSONValue]:
    if not isinstance(value, dict):
        raise StreamValidationError(f"{description} must be an object")
    return value


def _require_dict(record: dict[str, JSONValue], name: str) -> dict[str, JSONValue]:
    value = record.get(name)
    if not isinstance(value, dict):
        raise StreamValidationError(f"{name} must be an object")
    return value


def _require_list(record: dict[str, JSONValue], name: str) -> list[JSONValue]:
    value = record.get(name)
    if not isinstance(value, list):
        raise StreamValidationError(f"{name} must be an array")
    return value


def _require_str(record: dict[str, JSONValue], name: str) -> str:
    value = record.get(name)
    if type(value) is not str:
        raise StreamValidationError(f"{name} must be a string")
    return value


def _require_positive_int(record: dict[str, JSONValue], name: str) -> int:
    value = record.get(name)
    if type(value) is not int or value < 1:
        raise StreamValidationError(f"{name} must be a positive integer")
    return value

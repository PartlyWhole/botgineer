"""One-run native child protocol. Stdout is canonical NDJSON only."""

from __future__ import annotations

import json
import math
import select
import signal
import sys
from typing import Any, cast

from .api import InputCancelled, InputMode, InputProvider, TraceSink
from .engine import _run_with_host
from .options import TraceOptions
from .records import Record
from .serialization import canonical_record_bytes

_INTERRUPT_REQUESTED = False


def _stdin_buffer() -> Any:
    if sys.__stdin__ is None:
        raise RuntimeError("child stdin is unavailable")
    return cast(Any, sys.__stdin__).buffer


def _stdout_buffer() -> Any:
    if sys.__stdout__ is None:
        raise RuntimeError("child stdout is unavailable")
    return cast(Any, sys.__stdout__).buffer


def _read_control() -> dict[str, Any] | None:
    line = _stdin_buffer().readline()
    if not line:
        return None
    if not line.endswith(b"\n"):
        raise ValueError("control message is not newline terminated")
    value = json.loads(line)
    if type(value) is not dict:
        raise ValueError("control message must be an object")
    control: dict[str, Any] = value
    if canonical_record_bytes(control) != line:
        raise ValueError("control message is not canonical JSON")
    return control


class _NdjsonSink(TraceSink):
    def emit(self, record: Record) -> None:
        payload = canonical_record_bytes(record)
        previous_mask = signal.pthread_sigmask(signal.SIG_BLOCK, {signal.SIGINT})
        try:
            stream = _stdout_buffer()
            remaining = memoryview(payload)
            while remaining:
                written = stream.write(remaining)
                if type(written) is not int or written <= 0:
                    raise RuntimeError("child stdout made no write progress")
                remaining = remaining[written:]
            stream.flush()
        finally:
            signal.pthread_sigmask(signal.SIG_SETMASK, previous_mask)


class _ControlInput(InputProvider):
    input_mode: InputMode = "live"

    def __init__(self, run_id: str) -> None:
        self._run_id = run_id

    def provide_input(self, request_id: str, prompt: str) -> str | None:
        del prompt
        if _INTERRUPT_REQUESTED:
            raise InputCancelled
        while not select.select([_stdin_buffer()], [], [], 0.05)[0]:
            if _INTERRUPT_REQUESTED:
                raise InputCancelled
        control = _read_control()
        if control is None:
            return None
        if (
            set(control) != {"type", "run_id", "request_id", "line"}
            or control.get("type") != "input"
            or control.get("run_id") != self._run_id
            or control.get("request_id") != request_id
        ):
            raise ValueError("invalid input control")
        value = control.get("line")
        if type(value) is not str:
            raise ValueError("input control line must be an exact string")
        return value


def _options(value: object) -> TraceOptions:
    if type(value) is not dict:
        raise ValueError("run options must be an object")
    fields = dict(value)
    trace_modules = fields.get("trace_modules")
    if type(trace_modules) is not list:
        raise ValueError("trace_modules must be an array")
    fields["trace_modules"] = tuple(trace_modules)
    return TraceOptions(**fields)


def _cpu_limit(options: TraceOptions) -> bool:
    try:
        import resource

        _soft, hard = resource.getrlimit(resource.RLIMIT_CPU)
        requested = max(1, math.ceil(options.wall_clock_s) + 1)
        if hard != resource.RLIM_INFINITY:
            requested = min(requested, hard)
        resource.setrlimit(resource.RLIMIT_CPU, (requested, hard))
    except ImportError, OSError, ValueError:
        return False
    return True


def _interrupt(signum: int, frame: object) -> None:
    global _INTERRUPT_REQUESTED
    del signum, frame
    _INTERRUPT_REQUESTED = True


def _interrupt_requested() -> bool:
    return _INTERRUPT_REQUESTED


def main() -> int:
    control = _read_control()
    if control is None:
        raise ValueError("missing run control")
    if set(control) != {"type", "run_id", "source", "options"} or control.get("type") != "run":
        raise ValueError("invalid run control")
    run_id = control.get("run_id")
    source = control.get("source")
    if type(run_id) is not str or type(source) is not str:
        raise ValueError("run_id and source must be exact strings")
    options = _options(control.get("options"))
    cpu_limit = _cpu_limit(options)
    signal.signal(signal.SIGINT, _interrupt)
    platform_name = {"darwin": "macos", "linux": "linux"}.get(sys.platform)
    if platform_name is None:
        raise ValueError("unsupported native platform")
    host: dict[str, Any] = {
        "kind": "native_subprocess",
        "runtime": "cpython",
        "platform": platform_name,
        "input_mode": "live",
        "python_hash_seed": "0",
        "capabilities": {
            "live_input": True,
            "cooperative_interrupt": True,
            "hard_interrupt": True,
            "process_group": True,
            "cpu_limit": cpu_limit,
            "address_space_limit": False,
            "cross_origin_isolated": False,
        },
    }
    host_diagnostics: list[tuple[str, str]] = []
    if not cpu_limit:
        host_diagnostics.append(
            ("host_limit_unavailable", "the native host could not enforce its CPU limit")
        )
    host_diagnostics.append(
        (
            "host_limit_unavailable",
            "no verified native address-space limit is available for this run",
        )
    )
    _run_with_host(
        source,
        run_id=run_id,
        options=options,
        sink=_NdjsonSink(),
        input_provider=_ControlInput(run_id),
        host_info=host,
        host_diagnostics=tuple(host_diagnostics),
        interrupt_requested=_interrupt_requested,
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except BaseException as error:
        if type(error) is SystemExit:
            raise
        if sys.__stderr__ is not None:
            sys.__stderr__.write(f"pytrace child fatal: {type(error).__name__}\n")
        raise SystemExit(70) from None

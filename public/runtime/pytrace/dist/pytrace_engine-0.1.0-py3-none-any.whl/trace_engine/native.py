"""Async native subprocess host with process-group cleanup."""

from __future__ import annotations

import asyncio
import json
import os
import signal
import sys
import tempfile
from collections.abc import AsyncIterator
from contextlib import suppress
from typing import Any, cast

from .api import RunSummary, TerminalReason
from .engine import _header
from .options import TraceOptions
from .records import Record
from .serialization import (
    RecordLimitError,
    TraceBudget,
    TraceLimitError,
    canonical_record_bytes,
    finalize_terminal,
)
from .validation import _StreamValidator


class SubprocessSession:
    """One-run CPython subprocess session."""

    def __init__(self) -> None:
        self._started = False
        self._closed = False
        self._process: asyncio.subprocess.Process | None = None
        self._options: TraceOptions | None = None
        self._run_id = ""
        self._source = ""
        self._queue: asyncio.Queue[Record | None] = asyncio.Queue()
        self._ready = asyncio.Event()
        self._control_lock = asyncio.Lock()
        self._records: list[Record] = []
        self._stream_validator = _StreamValidator()
        self._reader_task: asyncio.Task[None] | None = None
        self._stderr_task: asyncio.Task[None] | None = None
        self._reaper_task: asyncio.Task[None] | None = None
        self._watchdog_task: asyncio.Task[None] | None = None
        self._kill_task: asyncio.Task[None] | None = None
        self._terminal: asyncio.Future[RunSummary] | None = None
        self._waiting_request: str | None = None
        self._hard_killed = False
        self._protocol_error = False
        self._temporary: tempfile.TemporaryDirectory[str] | None = None
        self.stderr = ""

    async def start(
        self,
        source: str,
        *,
        run_id: str,
        options: TraceOptions,
    ) -> None:
        if self._closed:
            raise RuntimeError("SubprocessSession is closed")
        if self._started:
            raise RuntimeError("SubprocessSession.start is single-use")
        if type(source) is not str:
            raise ValueError("source must be an exact string")
        if type(run_id) is not str or not run_id:
            raise ValueError("run_id must be a non-empty exact string")
        if type(options) is not TraceOptions:
            raise ValueError("options must be a TraceOptions instance")
        try:
            source_bytes = source.encode("utf-8")
        except UnicodeEncodeError as error:
            raise ValueError("source must be valid UTF-8") from error
        if len(source_bytes) > options.max_source_bytes:
            raise ValueError("source exceeds max_source_bytes")
        self._run_id = run_id
        self._source = source
        self._options = options
        try:
            TraceBudget(options.max_record_bytes, options.max_trace_bytes).admit_non_terminal(
                self._fallback_header()
            )
        except (RecordLimitError, TraceLimitError) as error:
            raise ValueError("header cannot fit the configured record and trace budgets") from error
        self._started = True
        self._terminal = asyncio.get_running_loop().create_future()
        self._temporary = tempfile.TemporaryDirectory(prefix="pytrace-")
        environment = {
            "PATH": os.environ.get("PATH", os.defpath),
            "PYTHONHASHSEED": "0",
            "PYTHONUNBUFFERED": "1",
        }
        try:
            self._process = await asyncio.create_subprocess_exec(
                sys.executable,
                "-u",
                "-m",
                "trace_engine._child",
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=self._temporary.name,
                env=environment,
                start_new_session=True,
                limit=options.max_record_bytes + 1,
            )
            control = {
                "type": "run",
                "run_id": run_id,
                "source": source,
                "options": options.to_record(),
            }
            await self._write_control(control)
        except BaseException:
            await self._terminate_group()
            self._cleanup_temporary()
            raise
        self._reader_task = asyncio.create_task(self._read_stdout())
        self._stderr_task = asyncio.create_task(self._read_stderr())
        self._reaper_task = asyncio.create_task(self._reap_process_group())
        self._watchdog_task = asyncio.create_task(self._watchdog())

    async def records(self) -> AsyncIterator[Record]:
        self._require_started()
        while True:
            record = await self._queue.get()
            if record is None:
                return
            yield record

    async def send_input(self, line: str) -> None:
        self._require_started()
        async with self._control_lock:
            if self._waiting_request is None:
                raise RuntimeError("no input request is outstanding")
            if type(line) is not str or "\n" in line or "\r" in line:
                raise ValueError("input line must be an exact string without a terminator")
            assert self._options is not None
            try:
                line_bytes = line.encode("utf-8")
            except UnicodeEncodeError as error:
                raise ValueError("input line must be valid UTF-8") from error
            if len(line_bytes) > self._options.max_input_line_bytes:
                raise ValueError("input line exceeds max_input_line_bytes")
            request_id = self._waiting_request
            self._waiting_request = None
            await self._write_control(
                {
                    "type": "input",
                    "run_id": self._run_id,
                    "request_id": request_id,
                    "line": line,
                }
            )

    async def interrupt(self) -> None:
        self._require_started()
        process = self._process
        if process is None or process.returncode is not None:
            return
        if not self._ready.is_set():
            try:
                await asyncio.wait_for(self._ready.wait(), timeout=0.5)
            except TimeoutError:
                if process.returncode is None:
                    self._hard_killed = True
                    self._kill_process_group()
                return
        if process.returncode is not None:
            return
        try:
            os.killpg(process.pid, signal.SIGINT)
        except ProcessLookupError:
            return
        if self._kill_task is None:
            self._kill_task = asyncio.create_task(self._kill_after_grace())

    async def wait(self) -> RunSummary:
        self._require_started()
        assert self._terminal is not None
        summary = await self._terminal
        if self._reader_task is not None:
            await self._reader_task
        if self._stderr_task is not None:
            await self._stderr_task
        if self._reaper_task is not None:
            await self._reaper_task
        self._cleanup_temporary()
        return summary

    async def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        process = self._process
        if process is not None and process.returncode is None:
            self._hard_killed = True
            with suppress(ProcessLookupError):
                os.killpg(process.pid, signal.SIGKILL)
            await process.wait()
        if process is not None:
            self._kill_process_group()
        for task in (self._watchdog_task, self._kill_task):
            if task is not None:
                task.cancel()
        cancelled = [task for task in (self._watchdog_task, self._kill_task) if task is not None]
        if cancelled:
            await asyncio.gather(*cancelled, return_exceptions=True)
        if self._reader_task is not None:
            await self._reader_task
        if self._stderr_task is not None:
            await self._stderr_task
        if self._reaper_task is not None:
            await self._reaper_task
        self._cleanup_temporary()

    async def _read_stdout(self) -> None:
        process = self._process
        assert process is not None and process.stdout is not None
        try:
            while True:
                try:
                    line = await process.stdout.readline()
                    if not line:
                        break
                    if not line.endswith(b"\n"):
                        raise ValueError("child emitted a partial NDJSON record")
                    value = json.loads(line)
                    if type(value) is not dict:
                        raise ValueError("child record must be an object")
                    record: Record = value
                    if canonical_record_bytes(record) != line:
                        raise ValueError("child record is not canonical NDJSON")
                    self._accept_record(record)
                except (
                    UnicodeDecodeError,
                    json.JSONDecodeError,
                    ValueError,
                    TypeError,
                    KeyError,
                ):
                    self._protocol_error = True
                    await self._terminate_group()
                    break
            await process.wait()
            self._kill_process_group()
            if (
                self._protocol_error
                and self._records
                and self._records[-1].get("kind") == "terminal"
            ):
                self._records.pop()
                self._reset_stream_validator()
            if not self._records:
                self._accept_record(self._fallback_header())
            if self._records[-1].get("kind") != "terminal":
                self._accept_record(self._synthetic_terminal())
            self._stream_validator.finish()
            terminal = self._records[-1]
            self._set_terminal_summary(terminal)
            self._queue.put_nowait(terminal)
        except Exception as error:
            assert self._terminal is not None
            if not self._terminal.done():
                self._terminal.set_exception(error)
        finally:
            await self._queue.put(None)

    def _accept_record(self, value: object) -> None:
        if type(value) is not dict:
            raise ValueError("child record must be an object")
        record: Record = value
        kind = record.get("kind")
        if kind == "header":
            self._validate_native_header(record)
        input_request: str | None = None
        if kind == "step" and record.get("event") == "input":
            event_data = record.get("event_data")
            if (
                type(event_data) is not dict
                or set(event_data) != {"kind", "request_id", "prompt"}
                or event_data.get("kind") != "input"
                or type(event_data.get("request_id")) is not str
                or not event_data["request_id"]
                or type(event_data.get("prompt")) is not str
            ):
                raise ValueError("input step has invalid event data")
            input_request = event_data["request_id"]
        is_terminal = record.get("kind") == "terminal"
        if is_terminal:
            self._validate_terminal_summary(record)
        self._stream_validator.accept(record)
        self._records.append(record)
        if kind == "header":
            self._ready.set()
        if input_request is not None:
            self._waiting_request = input_request
        if is_terminal:
            self._waiting_request = None
        else:
            self._queue.put_nowait(record)

    def _validate_terminal_summary(self, terminal: Record) -> None:
        summary = terminal.get("summary")
        if type(summary) is not dict:
            raise ValueError("terminal summary is invalid")
        reason = terminal.get("reason")
        if reason not in {
            "completed",
            "uncaught_exception",
            "step_limit",
            "trace_limit",
            "needs_input",
            "interrupted",
            "killed",
            "engine_error",
        }:
            raise ValueError("terminal reason is invalid")
        if type(terminal.get("trace_complete")) is not bool:
            raise ValueError("terminal trace_complete is invalid")
        for name in (
            "step_count",
            "diagnostic_count",
            "stdout_bytes",
            "stderr_bytes",
            "trace_bytes",
        ):
            if type(summary.get(name)) is not int or summary[name] < 0:
                raise ValueError(f"terminal summary {name} is invalid")

    def _set_terminal_summary(self, terminal: Record) -> None:
        assert self._terminal is not None
        if self._terminal.done():
            return
        self._validate_terminal_summary(terminal)
        summary = cast(dict[str, int], terminal["summary"])
        reason = cast(TerminalReason, terminal["reason"])
        self._terminal.set_result(
            RunSummary(
                run_id=self._run_id,
                terminal_reason=reason,
                terminal_seq=terminal["seq"],
                step_count=summary["step_count"],
                diagnostic_count=summary["diagnostic_count"],
                stdout_bytes=summary["stdout_bytes"],
                stderr_bytes=summary["stderr_bytes"],
                trace_bytes=summary["trace_bytes"],
                trace_complete=terminal["trace_complete"],
            )
        )

    def _synthetic_terminal(self) -> Record:
        assert self._options is not None
        reason: TerminalReason = "killed" if self._hard_killed else "engine_error"
        steps = [record for record in self._records if record.get("kind") == "step"]
        diagnostics = [record for record in self._records if record.get("kind") == "diagnostic"]
        output = steps[-1].get("output") if steps else {}
        stdout_bytes = output.get("stdout_bytes", 0) if isinstance(output, dict) else 0
        stderr_bytes = output.get("stderr_bytes", 0) if isinstance(output, dict) else 0
        terminal: Record = {
            "kind": "terminal",
            "seq": len(self._records),
            "reason": reason,
            "synthetic": True,
            "trace_complete": False,
            "summary": {
                "step_count": len(steps),
                "diagnostic_count": len(diagnostics),
                "stdout_bytes": stdout_bytes,
                "stderr_bytes": stderr_bytes,
                "trace_bytes": 1,
            },
        }
        prefix_bytes = sum(len(canonical_record_bytes(record)) for record in self._records)
        finalized, _ = finalize_terminal(
            terminal,
            prefix_bytes=prefix_bytes,
            max_record_bytes=self._options.max_record_bytes,
            max_trace_bytes=self._options.max_trace_bytes,
        )
        return finalized

    def _fallback_header(self) -> Record:
        assert self._options is not None
        platform_name = {"darwin": "macos", "linux": "linux"}.get(sys.platform)
        if platform_name is None:
            raise ValueError("native subprocess supports only Linux and macOS")
        host: dict[str, Any] = {
            "kind": "native_subprocess",
            "runtime": "cpython",
            "platform": platform_name,
            "input_mode": "live",
            "python_hash_seed": "0",
            "capabilities": {
                "live_input": True,
                "cooperative_interrupt": True,
                "hard_interrupt": True,
                "process_group": True,
                "cpu_limit": False,
                "address_space_limit": False,
                "cross_origin_isolated": False,
            },
        }
        source_bytes = self._source.encode("utf-8")
        return _header(
            self._run_id,
            self._source,
            source_bytes,
            self._options,
            "live",
            host,
        )

    def _validate_native_header(self, record: Record) -> None:
        expected = self._fallback_header()
        for name, value in expected.items():
            if name != "host" and record.get(name) != value:
                raise ValueError(f"child header {name} does not match the requested run")
        host = record.get("host")
        expected_host = expected["host"]
        if type(host) is not dict or type(expected_host) is not dict:
            raise ValueError("child header host is invalid")
        if set(host) != set(expected_host):
            raise ValueError("child header host fields are invalid")
        for name, value in expected_host.items():
            if name != "capabilities" and host.get(name) != value:
                raise ValueError(f"child header host {name} is invalid")
        capabilities = host.get("capabilities")
        expected_capabilities = expected_host["capabilities"]
        if type(capabilities) is not dict or type(expected_capabilities) is not dict:
            raise ValueError("child header capabilities are invalid")
        if set(capabilities) != set(expected_capabilities):
            raise ValueError("child header capability fields are invalid")
        if type(capabilities.get("cpu_limit")) is not bool:
            raise ValueError("child header cpu_limit capability is invalid")
        for name, value in expected_capabilities.items():
            if name != "cpu_limit" and capabilities.get(name) != value:
                raise ValueError(f"child header capability {name} is invalid")

    def _reset_stream_validator(self) -> None:
        self._stream_validator = _StreamValidator()
        for record in self._records:
            self._stream_validator.accept(record)

    async def _watchdog(self) -> None:
        assert self._options is not None
        elapsed = 0.0
        interval = 0.05
        loop = asyncio.get_running_loop()
        previous = loop.time()
        try:
            while True:
                await asyncio.sleep(interval)
                current = loop.time()
                process = self._process
                if process is None:
                    return
                if process.returncode is not None:
                    self._kill_process_group()
                    return
                if self._waiting_request is None:
                    elapsed += current - previous
                previous = current
                if elapsed >= self._options.wall_clock_s:
                    await self.interrupt()
                    return
        except asyncio.CancelledError:
            return

    async def _kill_after_grace(self) -> None:
        await asyncio.sleep(0.5)
        process = self._process
        if process is not None and process.returncode is None:
            self._hard_killed = True
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                return

    async def _terminate_group(self) -> None:
        process = self._process
        if process is None:
            return
        self._protocol_error = True
        self._kill_process_group()
        if process.returncode is None:
            await process.wait()

    async def _write_control(self, control: dict[str, Any]) -> None:
        process = self._process
        if process is None or process.stdin is None or process.stdin.is_closing():
            raise RuntimeError("child control channel is closed")
        payload = (
            json.dumps(
                control,
                ensure_ascii=True,
                allow_nan=False,
                separators=(",", ":"),
                sort_keys=True,
            ).encode("ascii")
            + b"\n"
        )
        process.stdin.write(payload)
        await process.stdin.drain()

    async def _read_stderr(self) -> None:
        process = self._process
        assert process is not None and process.stderr is not None
        retained = bytearray()
        while payload := await process.stderr.read(4096):
            available = (64 * 1024) - len(retained)
            if available > 0:
                retained.extend(payload[:available])
        self.stderr = bytes(retained).decode("utf-8", "replace")

    async def _reap_process_group(self) -> None:
        process = self._process
        assert process is not None
        await process.wait()
        self._kill_process_group()

    def _require_started(self) -> None:
        if not self._started:
            raise RuntimeError("SubprocessSession has not started")

    def _cleanup_temporary(self) -> None:
        if self._temporary is not None:
            self._temporary.cleanup()
            self._temporary = None

    def _kill_process_group(self) -> None:
        process = self._process
        if process is None:
            return
        with suppress(ProcessLookupError):
            os.killpg(process.pid, signal.SIGKILL)

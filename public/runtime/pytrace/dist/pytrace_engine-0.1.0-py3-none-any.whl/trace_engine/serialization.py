"""Canonical JSON serialization and trace-byte admission."""

from __future__ import annotations

import json
import math
from copy import deepcopy
from dataclasses import dataclass
from typing import Final, cast

from .records import Record

TERMINAL_RESERVE_BYTES: Final = 8 * 1024


class SerializationError(ValueError):
    """Raised when a value cannot be represented on the canonical wire."""


class RecordLimitError(ValueError):
    """Raised when no schema-valid representation fits a record budget."""


class TraceLimitError(ValueError):
    """Raised when a record cannot fit the remaining trace budget."""


def canonical_record_bytes(record: Record) -> bytes:
    """Serialize one closed record as canonical ASCII NDJSON."""

    _validate_exact_json_tree(record)
    try:
        text = json.dumps(
            record,
            ensure_ascii=True,
            allow_nan=False,
            check_circular=True,
            separators=(",", ":"),
            sort_keys=True,
        )
    except (TypeError, ValueError, RecursionError) as error:
        raise SerializationError("record is not canonical-JSON serializable") from error
    return text.encode("ascii") + b"\n"


def _validate_exact_json_tree(value: object) -> None:
    stack = [value]
    seen_containers: set[int] = set()
    while stack:
        current = stack.pop()
        current_type = type(current)
        if current_type is dict:
            if id(current) in seen_containers:
                continue
            seen_containers.add(id(current))
            mapping = cast(dict[object, object], current)
            if any(type(key) is not str for key in mapping):
                raise SerializationError("JSON object keys must be exact strings")
            stack.extend(mapping.values())
        elif current_type is list:
            if id(current) in seen_containers:
                continue
            seen_containers.add(id(current))
            stack.extend(cast(list[object], current))
        elif current is None or current_type in {bool, int, str}:
            continue
        elif current_type is float:
            if not math.isfinite(cast(float, current)):
                raise SerializationError("non-finite JSON numbers are forbidden")
        else:
            raise SerializationError(f"unsupported JSON value type: {current_type.__name__}")


def record_size(record: Record) -> int:
    """Return the exact wire size of one canonical record."""

    return len(canonical_record_bytes(record))


def finalize_terminal(
    terminal: Record,
    *,
    prefix_bytes: int,
    max_record_bytes: int,
    max_trace_bytes: int,
) -> tuple[Record, bytes]:
    """Set the terminal's self-inclusive trace byte count to its stable value."""

    if terminal.get("kind") != "terminal":
        raise ValueError("terminal record required")
    if type(prefix_bytes) is not int or prefix_bytes < 0:
        raise ValueError("prefix_bytes must be a non-negative integer")

    _validate_exact_json_tree(terminal)
    finalized = deepcopy(terminal)
    summary = finalized.get("summary")
    if not isinstance(summary, dict):
        raise ValueError("terminal summary object required")

    candidate = max(prefix_bytes + 1, 1)
    for _ in range(32):
        summary["trace_bytes"] = candidate
        payload = canonical_record_bytes(finalized)
        stable = prefix_bytes + len(payload)
        if stable == candidate:
            if len(payload) > max_record_bytes:
                raise RecordLimitError("terminal exceeds max_record_bytes")
            if stable > max_trace_bytes:
                raise TraceLimitError("terminal exceeds max_trace_bytes")
            return finalized, payload
        candidate = stable
    raise SerializationError("terminal trace_bytes did not reach a stable value")


@dataclass(slots=True)
class TraceBudget:
    """Track exact bytes while preserving space for a minimal terminal."""

    max_record_bytes: int
    max_trace_bytes: int
    terminal_reserve_bytes: int = TERMINAL_RESERVE_BYTES
    trace_bytes: int = 0

    def admit_non_terminal(self, record: Record) -> bytes:
        payload = canonical_record_bytes(record)
        if len(payload) > self.max_record_bytes:
            raise RecordLimitError("record exceeds max_record_bytes")
        if self.trace_bytes + len(payload) + self.terminal_reserve_bytes > self.max_trace_bytes:
            raise TraceLimitError("record would consume the terminal reserve")
        self.trace_bytes += len(payload)
        return payload

    def finalize_terminal(self, terminal: Record) -> tuple[Record, bytes]:
        finalized, payload = finalize_terminal(
            terminal,
            prefix_bytes=self.trace_bytes,
            max_record_bytes=self.max_record_bytes,
            max_trace_bytes=self.max_trace_bytes,
        )
        self.trace_bytes += len(payload)
        return finalized, payload

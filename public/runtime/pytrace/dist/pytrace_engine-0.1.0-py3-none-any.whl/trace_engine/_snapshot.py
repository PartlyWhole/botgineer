"""Non-public synthetic snapshot seam used before tracing is implemented."""

from __future__ import annotations

from collections import deque
from collections.abc import Iterator, Sequence
from dataclasses import dataclass
from typing import Literal

from .closures import FunctionProvenanceResolver
from .encoder import SnapshotEncoder
from .identity import IdentityRegistry
from .options import TraceOptions
from .records import EncodedValue, HeapNode, JSONValue, Record
from .serialization import RecordLimitError, record_size

type SnapshotEvent = Literal[
    "call",
    "resume",
    "line",
    "yield",
    "return",
    "exception",
    "unwind",
    "input",
]


@dataclass(frozen=True, slots=True)
class SnapshotLocation:
    filename: str
    module: str
    function: str
    line: int

    def to_record(self) -> dict[str, JSONValue]:
        if type(self.line) is not int or self.line < 1:
            raise ValueError("line must be a positive integer")
        return {
            "filename": self.filename,
            "module": self.module,
            "function": self.function,
            "line": self.line,
        }


@dataclass(frozen=True, slots=True)
class SnapshotFrame:
    frame_id: int
    function: str
    module: str
    location: SnapshotLocation
    locals: tuple[tuple[str, object], ...]


@dataclass(frozen=True, slots=True)
class SnapshotGlobals:
    module: str
    bindings: tuple[tuple[str, object], ...]


@dataclass(frozen=True, slots=True)
class ValueEvent:
    value: object


@dataclass(frozen=True, slots=True)
class ExceptionEvent:
    exception: object


@dataclass(frozen=True, slots=True)
class InputEvent:
    request_id: str
    prompt: str


type SnapshotEventData = ValueEvent | ExceptionEvent | InputEvent | None


@dataclass(frozen=True, slots=True)
class SnapshotContext:
    seq: int
    step: int
    event: SnapshotEvent
    location: SnapshotLocation
    stack: tuple[SnapshotFrame, ...]
    globals: tuple[SnapshotGlobals, ...]
    output: dict[str, str | int]
    event_data: SnapshotEventData = None
    output_truncated: bool = False
    degraded: bool = False
    identity_ambiguous: bool = False


def encode_snapshot(
    context: SnapshotContext,
    options: TraceOptions,
    *,
    identity_registry: IdentityRegistry | None = None,
    provenance_resolver: FunctionProvenanceResolver | None = None,
) -> Record:
    """Build one complete synthetic step without installing a trace function."""

    _validate_context(context)
    roots: list[object] = []
    frame_specs: list[tuple[SnapshotFrame, tuple[tuple[str, object], ...]]] = []
    global_specs: list[tuple[SnapshotGlobals, tuple[tuple[str, object], ...]]] = []
    container_elided = False

    for frame in context.stack:
        selected, omitted = _bounded_bindings(frame.locals, options.max_container_elems)
        container_elided |= omitted
        frame_specs.append((frame, selected))
        roots.extend(value for _, value in selected)
    for scope in context.globals:
        selected, omitted = _bounded_bindings(scope.bindings, options.max_container_elems)
        container_elided |= omitted
        global_specs.append((scope, selected))
        roots.extend(value for _, value in selected)

    if isinstance(context.event_data, (ValueEvent, ExceptionEvent)):
        roots.append(
            context.event_data.value
            if isinstance(context.event_data, ValueEvent)
            else context.event_data.exception
        )

    active_registry = identity_registry or IdentityRegistry(options.identity_tombstones)
    graph = SnapshotEncoder(
        options,
        identity_registry=active_registry,
        provenance_resolver=provenance_resolver,
        current_frame_ids={frame.frame_id for frame in context.stack},
    ).encode(roots)
    root_iter = iter(graph.roots)
    root_targets: list[EncodedValue] = []
    stack_records: list[JSONValue] = []
    for frame, bindings in frame_specs:
        encoded_bindings = _encode_bindings(bindings, root_iter, root_targets)
        stack_records.append(
            {
                "frame_id": frame.frame_id,
                "function": frame.function,
                "module": frame.module,
                "location": frame.location.to_record(),
                "locals": encoded_bindings,
            }
        )

    global_records: list[JSONValue] = []
    for scope, bindings in global_specs:
        global_records.append(
            {
                "module": scope.module,
                "bindings": _encode_bindings(bindings, root_iter, root_targets),
            }
        )

    record: Record = {
        "kind": "step",
        "seq": context.seq,
        "step": context.step,
        "event": context.event,
        "location": context.location.to_record(),
        "stack": stack_records,
        "globals": global_records,
        "closure_environments": graph.closure_environments,
        "heap": graph.heap,
        "output": dict(context.output),
        "flags": {
            "heap_elided": graph.heap_elided,
            "edges_elided": graph.edges_elided,
            "container_elided": graph.container_elided or container_elided,
            "output_truncated": context.output_truncated,
            "degraded": context.degraded,
            "identity_ambiguous": context.identity_ambiguous or graph.identity_ambiguous,
        },
    }
    _add_event_data(record, context.event, context.event_data, root_iter, root_targets)
    _fit_record_budget(record, root_targets, options.max_record_bytes)
    heap = record.get("heap")
    assert isinstance(heap, list)
    visible_uids = {
        uid for node in heap if isinstance(node, dict) and type(uid := node.get("uid")) is int
    }
    active_registry.retain_visible_uids(visible_uids)
    flags = record.get("flags")
    assert isinstance(flags, dict)
    flags["identity_ambiguous"] = context.identity_ambiguous or bool(
        graph.ambiguous_uids & visible_uids
    )
    return record


def _validate_context(context: SnapshotContext) -> None:
    if type(context.seq) is not int or context.seq < 1:
        raise ValueError("snapshot seq must be a positive integer")
    if type(context.step) is not int or context.step < 0:
        raise ValueError("snapshot step must be a non-negative integer")
    if not context.stack:
        raise ValueError("snapshot stack must not be empty")
    if not context.globals or context.globals[0].module != "__main__":
        raise ValueError("__main__ globals must be first")
    if len({frame.frame_id for frame in context.stack}) != len(context.stack):
        raise ValueError("frame IDs must be unique")
    for frame in context.stack:
        if type(frame.frame_id) is not int or frame.frame_id < 1:
            raise ValueError("frame IDs must be positive integers")
        _validate_bindings(frame.locals)
    for scope in context.globals:
        _validate_bindings(scope.bindings)

    output_keys = {"stdout_delta", "stderr_delta", "stdout_bytes", "stderr_bytes"}
    if set(context.output) != output_keys:
        raise ValueError("output must contain the four canonical fields")
    if context.event in {"call", "resume", "line"} and context.event_data is not None:
        raise ValueError(f"{context.event} does not accept event_data")
    if context.event in {"yield", "return"} and not isinstance(context.event_data, ValueEvent):
        raise ValueError(f"{context.event} requires ValueEvent")
    if context.event in {"exception", "unwind"} and not isinstance(
        context.event_data, ExceptionEvent
    ):
        raise ValueError(f"{context.event} requires ExceptionEvent")
    if context.event == "input" and not isinstance(context.event_data, InputEvent):
        raise ValueError("input requires InputEvent")
    if isinstance(context.event_data, InputEvent) and (
        type(context.event_data.request_id) is not str or not context.event_data.request_id
    ):
        raise ValueError("input request_id must be a non-empty exact string")


def _validate_bindings(bindings: tuple[tuple[str, object], ...]) -> None:
    names = [name for name, _ in bindings]
    if any(type(name) is not str for name in names) or len(set(names)) != len(names):
        raise ValueError("binding names must be unique exact strings")


def _bounded_bindings(
    bindings: tuple[tuple[str, object], ...],
    limit: int,
) -> tuple[tuple[tuple[str, object], ...], bool]:
    return bindings[:limit], len(bindings) > limit


def _encode_bindings(
    bindings: tuple[tuple[str, object], ...],
    roots: Iterator[EncodedValue],
    targets: list[EncodedValue],
) -> list[JSONValue]:
    result: list[JSONValue] = []
    for name, _ in bindings:
        encoded = next(roots)
        targets.append(encoded)
        result.append({"name": name, "value": encoded})
    return result


def _add_event_data(
    record: Record,
    event: SnapshotEvent,
    event_data: SnapshotEventData,
    roots: Iterator[EncodedValue],
    targets: list[EncodedValue],
) -> None:
    if event in {"yield", "return"}:
        encoded = next(roots)
        targets.append(encoded)
        record["event_data"] = {"kind": "value", "value": encoded}
    elif event in {"exception", "unwind"}:
        encoded = next(roots)
        targets.append(encoded)
        record["event_data"] = {"kind": "exception", "exception": encoded}
    elif event == "input":
        assert isinstance(event_data, InputEvent)
        record["event_data"] = {
            "kind": "input",
            "request_id": event_data.request_id,
            "prompt": event_data.prompt,
        }


def _fit_record_budget(
    record: Record,
    root_targets: list[EncodedValue],
    max_record_bytes: int,
) -> None:
    flags = record.get("flags")
    if not isinstance(flags, dict):
        raise ValueError("snapshot flags object required")
    if record_size(record) <= max_record_bytes:
        return

    for value in _large_inline_values(record):
        value.clear()
        value.update({"kind": "elided", "reason": "record_limit"})
        _repair_set_ordering(record)
        flags["heap_elided"] = True
        if record_size(record) <= max_record_bytes:
            return

    heap = record["heap"]
    assert isinstance(heap, list)
    while heap:
        node = heap[-1]
        assert isinstance(node, dict)
        uid = node.get("uid")
        assert isinstance(uid, int)
        _replace_uid(record, uid)
        _repair_closure_environments(record, root_targets)
        _repair_set_ordering(record)
        flags["heap_elided"] = True
        if record_size(record) <= max_record_bytes:
            return

    for value in root_targets:
        value.clear()
        value.update({"kind": "elided", "reason": "record_limit"})
        _repair_closure_environments(record, root_targets)
        _prune_unreachable_heap(record, root_targets)
        _repair_set_ordering(record)
        flags["heap_elided"] = True
        if record_size(record) <= max_record_bytes:
            return
    raise RecordLimitError("snapshot structure cannot fit max_record_bytes")


def _large_inline_values(record: Record) -> list[EncodedValue]:
    result: list[tuple[int, EncodedValue]] = []
    stack: list[JSONValue] = [record]
    while stack:
        value = stack.pop()
        if isinstance(value, dict):
            if value.get("kind") in {"str", "bytes"}:
                result.append((record_size(value), value))
            else:
                stack.extend(value.values())
        elif isinstance(value, list):
            stack.extend(value)
    result.sort(key=lambda item: item[0], reverse=True)
    return [value for _, value in result]


def _replace_uid(record: Record, uid: int) -> None:
    stack: list[JSONValue] = [record]
    while stack:
        value = stack.pop()
        if isinstance(value, dict):
            if value.get("kind") == "ref" and value.get("uid") == uid:
                value.clear()
                value.update({"kind": "elided", "reason": "record_limit"})
            else:
                stack.extend(value.values())
        elif isinstance(value, list):
            stack.extend(value)


def _repair_set_ordering(record: Record) -> None:
    for value in _walk_dicts(record):
        if value.get("kind") not in {"set", "frozenset"}:
            continue
        items = value.get("items")
        if not isinstance(items, list):
            continue
        if any(isinstance(item, dict) and item.get("kind") == "elided" for item in items):
            value["ordering"] = "unordered"


def _repair_closure_environments(record: Record, roots: list[EncodedValue]) -> None:
    heap = record.get("heap")
    environments = record.get("closure_environments")
    if not isinstance(heap, list) or not isinstance(environments, list):
        raise ValueError("snapshot heap and closure environments must be arrays")
    nodes = {
        node.get("uid"): node
        for node in heap
        if isinstance(node, dict) and type(node.get("uid")) is int
    }
    valid_environment_ids: set[int] = set()
    for environment in environments:
        if not isinstance(environment, dict):
            continue
        environment_id = environment.get("environment_id")
        cells = environment.get("cells")
        if type(environment_id) is not int or not isinstance(cells, list):
            continue
        valid = True
        for binding in cells:
            if not isinstance(binding, dict):
                valid = False
                break
            value = binding.get("value")
            if not isinstance(value, dict) or value.get("kind") != "ref":
                valid = False
                break
            node = nodes.get(value.get("uid"))
            if node is None or node.get("kind") != "cell":
                valid = False
                break
        if valid:
            valid_environment_ids.add(environment_id)

    for node in tuple(nodes.values()):
        environment_id = node.get("closure_environment_id")
        if environment_id is not None and environment_id not in valid_environment_ids:
            uid = node.get("uid")
            if type(uid) is int:
                _replace_uid(record, uid)
    environments[:] = [
        environment
        for environment in environments
        if isinstance(environment, dict)
        and environment.get("environment_id") in valid_environment_ids
    ]
    _prune_unreachable_heap(record, roots)


def _prune_unreachable_heap(record: Record, roots: list[EncodedValue]) -> None:
    heap = record["heap"]
    assert isinstance(heap, list)
    nodes: dict[int, HeapNode] = {}
    for value in heap:
        assert isinstance(value, dict)
        uid = value.get("uid")
        assert isinstance(uid, int)
        nodes[uid] = value

    environments = record.get("closure_environments")
    assert isinstance(environments, list)
    environment_by_id = {
        environment.get("environment_id"): environment
        for environment in environments
        if isinstance(environment, dict) and type(environment.get("environment_id")) is int
    }
    used_environment_ids: set[int] = set()
    reachable: set[int] = set()
    pending = deque(_referenced_uids(roots))
    while pending:
        uid = pending.popleft()
        if uid in reachable or uid not in nodes:
            continue
        reachable.add(uid)
        node = nodes[uid]
        pending.extend(_referenced_uids([node]))
        environment_id = node.get("closure_environment_id")
        environment = environment_by_id.get(environment_id)
        if type(environment_id) is int and environment is not None:
            used_environment_ids.add(environment_id)
            pending.extend(_referenced_uids([environment]))
    retained: list[HeapNode] = []
    for node in heap:
        if isinstance(node, dict) and node.get("uid") in reachable:
            retained.append(node)
    heap[:] = retained
    environments[:] = [
        environment
        for environment in environments
        if isinstance(environment, dict)
        and environment.get("environment_id") in used_environment_ids
    ]


def _referenced_uids(values: Sequence[object]) -> set[int]:
    result: set[int] = set()
    stack = list(values)
    while stack:
        value = stack.pop()
        if isinstance(value, dict):
            uid = value.get("uid")
            if value.get("kind") == "ref" and type(uid) is int:
                result.add(uid)
            else:
                stack.extend(value.values())
        elif isinstance(value, list):
            stack.extend(value)
    return result


def _walk_dicts(value: object) -> Iterator[dict[str, object]]:
    stack = [value]
    while stack:
        current = stack.pop()
        if isinstance(current, dict):
            yield current
            stack.extend(current.values())
        elif isinstance(current, list):
            stack.extend(current)

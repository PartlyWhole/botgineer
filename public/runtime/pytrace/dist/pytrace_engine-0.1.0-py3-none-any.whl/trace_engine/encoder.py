"""Iterative, hook-avoiding object graph encoding."""

from __future__ import annotations

import base64
import inspect
import math
import types
from collections import deque
from collections.abc import Generator
from dataclasses import dataclass
from typing import Any, Final, Literal, cast

from .closures import FunctionProvenanceResolver
from .identity import IdentityRegistry
from .options import TraceOptions
from .records import EncodedValue, HeapNode
from .serialization import canonical_record_bytes

_CELL_TYPE: Final = types.CellType
_MISSING: Final = object()


@dataclass(slots=True)
class EncodedGraph:
    """One self-contained heap plus encoded roots."""

    roots: list[EncodedValue]
    heap: list[HeapNode]
    heap_elided: bool
    edges_elided: bool
    container_elided: bool
    identity_ambiguous: bool
    ambiguous_uids: set[int]
    closure_environments: list[dict[str, Any]]


@dataclass(slots=True)
class _PendingNode:
    uid: int
    value: object


class SnapshotEncoder:
    """Encode one snapshot without recursive heap traversal."""

    def __init__(
        self,
        options: TraceOptions,
        *,
        identity_registry: IdentityRegistry | None = None,
        provenance_resolver: FunctionProvenanceResolver | None = None,
        current_frame_ids: set[int] | None = None,
    ) -> None:
        self._options = options
        self._identity_registry = identity_registry or IdentityRegistry(options.identity_tombstones)
        if self._identity_registry.tombstone_limit != options.identity_tombstones:
            raise ValueError("identity registry tombstone limit does not match options")
        self._provenance_resolver = provenance_resolver
        self._current_frame_ids = current_frame_ids or set()
        self._uid_by_raw_id: dict[int, int] = {}
        self._memo: set[int] = set()
        self._pending: deque[_PendingNode] = deque()
        self._nodes: dict[int, HeapNode] = {}
        self._edge_count = 0
        self._heap_elided = False
        self._edges_elided = False
        self._container_elided = False
        self._identity_ambiguous = False
        self._ambiguous_uids: set[int] = set()
        self._closure_environment_by_key: dict[tuple[tuple[str, int], ...], int] = {}
        self._closure_environments: dict[int, dict[str, Any]] = {}

    def encode(self, roots: list[object]) -> EncodedGraph:
        """Encode roots and drain every reserved node before returning."""

        self._identity_registry.begin_snapshot()
        try:
            encoded_roots = [self._encode_value(value) for value in roots]
            while self._pending:
                pending = self._pending.popleft()
                try:
                    node = self._build_node(pending.uid, pending.value)
                except Exception:
                    node = self._opaque_node(pending.uid, pending.value, "adapter_error")
                self._nodes[pending.uid] = node
        except BaseException:
            self._identity_registry.abort_snapshot()
            raise
        self._identity_registry.end_snapshot()

        heap = [self._nodes[uid] for uid in sorted(self._nodes)]
        used_environment_ids = {
            environment_id
            for node in heap
            if type(environment_id := node.get("closure_environment_id")) is int
        }
        return EncodedGraph(
            roots=encoded_roots,
            heap=heap,
            heap_elided=self._heap_elided,
            edges_elided=self._edges_elided,
            container_elided=self._container_elided,
            identity_ambiguous=self._identity_ambiguous,
            ambiguous_uids=set(self._ambiguous_uids),
            closure_environments=[
                self._closure_environments[environment_id]
                for environment_id in sorted(used_environment_ids)
            ],
        )

    def _encode_value(self, value: object) -> EncodedValue:
        scalar = self._inline_scalar(value)
        if scalar is not None:
            return scalar
        if type(value) is slice:
            return {
                "kind": "slice",
                "start": self._encode_value(value.start),
                "stop": self._encode_value(value.stop),
                "step": self._encode_value(value.step),
            }

        raw_id = id(value)
        if raw_id in self._uid_by_raw_id:
            return {"kind": "ref", "uid": self._uid_by_raw_id[raw_id]}
        if len(self._memo) >= self._options.max_heap_nodes:
            self._heap_elided = True
            return {"kind": "elided", "reason": "node_limit"}

        resolution = self._identity_registry.observe(value)
        uid = resolution.uid
        self._identity_ambiguous |= resolution.ambiguous
        if resolution.ambiguous:
            self._ambiguous_uids.add(uid)
        self._uid_by_raw_id[raw_id] = uid
        self._memo.add(uid)
        self._pending.append(_PendingNode(uid=uid, value=value))
        return {"kind": "ref", "uid": uid}

    def _encode_edge(self, value: object) -> EncodedValue:
        if not self._reserve_edges(1):
            return {"kind": "elided", "reason": "edge_limit"}
        return self._encode_value(value)

    def _reserve_edges(self, count: int) -> bool:
        if self._edge_count + count > self._options.max_heap_edges:
            self._edges_elided = True
            return False
        self._edge_count += count
        return True

    def _inline_scalar(self, value: object) -> EncodedValue | None:
        value_type = type(value)
        if value is None:
            return {"kind": "none"}
        if value_type is bool:
            return {"kind": "bool", "value": cast(bool, value)}
        if value_type is int:
            return {"kind": "int", "decimal": str(cast(int, value))}
        if value_type is float:
            return self._float_value(cast(float, value))
        if value_type is str:
            return {"kind": "str", "value": cast(str, value)}
        if value_type is bytes:
            bytes_value = cast(bytes, value)
            return {
                "kind": "bytes",
                "base64": base64.b64encode(bytes_value).decode("ascii"),
                "length": len(bytes_value),
            }
        if value_type is complex:
            complex_value = cast(complex, value)
            return {
                "kind": "complex",
                "real": self._float_value(complex_value.real),
                "imag": self._float_value(complex_value.imag),
            }
        if value_type is range:
            range_value = cast(range, value)
            return {
                "kind": "range",
                "start": {"kind": "int", "decimal": str(range_value.start)},
                "stop": {"kind": "int", "decimal": str(range_value.stop)},
                "step": {"kind": "int", "decimal": str(range_value.step)},
            }
        if value_type is slice:
            slice_value = cast(slice, value)
            parts: list[EncodedValue] = []
            for part in (slice_value.start, slice_value.stop, slice_value.step):
                encoded = self._inline_scalar(part)
                if encoded is None or encoded.get("kind") in {"ref", "elided"}:
                    return None
                parts.append(encoded)
            return {"kind": "slice", "start": parts[0], "stop": parts[1], "step": parts[2]}
        if value is Ellipsis:
            return {"kind": "ellipsis"}
        if value is NotImplemented:
            return {"kind": "not_implemented"}
        return None

    @staticmethod
    def _float_value(value: float) -> EncodedValue:
        if math.isnan(value):
            return {"kind": "float", "special": "NaN"}
        if math.isinf(value):
            special = "Infinity" if value > 0 else "-Infinity"
            return {"kind": "float", "special": special}
        return {"kind": "float", "decimal": repr(value)}

    def _build_node(self, uid: int, value: object) -> HeapNode:
        value_type = type(value)
        if value_type is list:
            return self._sequence_node(uid, "list", cast(list[object], value))
        if value_type is tuple:
            return self._sequence_node(uid, "tuple", cast(tuple[object, ...], value))
        if value_type is set:
            return self._set_node(uid, "set", cast(set[object], value))
        if value_type is frozenset:
            return self._set_node(uid, "frozenset", cast(frozenset[object], value))
        if value_type is dict:
            return self._dict_node(uid, cast(dict[object, object], value))
        if value_type is types.FunctionType:
            return self._function_node(uid, cast(types.FunctionType, value))
        if self._is_class_object(value_type):
            return self._class_node(uid, cast(type[object], value))
        if value_type is types.GeneratorType:
            return self._generator_node(uid, cast(Generator[Any, Any, Any], value))
        if value_type is _CELL_TYPE:
            return self._cell_node(uid, cast(types.CellType, value))
        if value_type is types.ModuleType:
            return self._module_node(uid, cast(types.ModuleType, value))
        if self._is_iterator_type(value_type):
            return {"uid": uid, "kind": "iterator", "type_name": self._type_name(value_type)}
        return self._instance_node(uid, value)

    def _sequence_node(
        self,
        uid: int,
        kind: str,
        value: list[object] | tuple[object, ...],
    ) -> HeapNode:
        limit = self._options.max_container_elems
        total = len(value)
        selected = value[:limit]
        items: list[EncodedValue] = []
        container_omitted = max(total - len(selected), 0)
        edge_omitted = 0
        for index, child in enumerate(selected):
            encoded = self._encode_edge(child)
            if encoded.get("reason") == "edge_limit":
                edge_omitted = len(selected) - index
                items.append(
                    {
                        "kind": "elided",
                        "reason": "edge_limit",
                        "omitted_count": edge_omitted,
                    }
                )
                break
            items.append(encoded)
        if container_omitted:
            self._container_elided = True
            items.append(
                {
                    "kind": "elided",
                    "reason": "container_limit",
                    "omitted_count": container_omitted,
                }
            )
        return {
            "uid": uid,
            "kind": kind,
            "type_name": kind,
            "ordering": "insertion",
            "items": items,
            "elided_count": container_omitted + edge_omitted,
        }

    def _set_node(
        self,
        uid: int,
        kind: str,
        value: set[object] | frozenset[object],
    ) -> HeapNode:
        raw_items = list(value)
        scalar_items: list[EncodedValue] = []
        all_scalar = True
        for child in raw_items:
            scalar = self._inline_scalar(child)
            if scalar is None:
                all_scalar = False
                break
            scalar_items.append(scalar)
        if all_scalar:
            scalar_items.sort(key=canonical_record_bytes)
            source_items: list[object | EncodedValue] = list(scalar_items)
        else:
            source_items = raw_items

        limit = self._options.max_container_elems
        selected = source_items[:limit]
        container_omitted = max(len(source_items) - len(selected), 0)
        edge_omitted = 0
        items: list[EncodedValue] = []
        for index, child in enumerate(selected):
            if not self._reserve_edges(1):
                edge_omitted = len(selected) - index
                items.append(
                    {
                        "kind": "elided",
                        "reason": "edge_limit",
                        "omitted_count": edge_omitted,
                    }
                )
                break
            encoded = cast(EncodedValue, child) if all_scalar else self._encode_value(child)
            items.append(encoded)

        if container_omitted:
            self._container_elided = True
            items.append(
                {
                    "kind": "elided",
                    "reason": "container_limit",
                    "omitted_count": container_omitted,
                }
            )
        omitted = container_omitted + edge_omitted
        ordering = "canonical" if all_scalar and not omitted else "unordered"
        return {
            "uid": uid,
            "kind": kind,
            "type_name": kind,
            "ordering": ordering,
            "items": items,
            "elided_count": omitted,
        }

    def _dict_node(self, uid: int, value: dict[object, object]) -> HeapNode:
        raw_entries = list(value.items())
        limit = self._options.max_container_elems
        selected = raw_entries[:limit]
        container_omitted = max(len(raw_entries) - len(selected), 0)
        edge_omitted = 0
        entries: list[dict[str, EncodedValue]] = []
        for index, (key, child) in enumerate(selected):
            if not self._reserve_edges(2):
                edge_omitted = len(selected) - index
                break
            entries.append({"key": self._encode_value(key), "value": self._encode_value(child)})
        if container_omitted:
            self._container_elided = True
        return {
            "uid": uid,
            "kind": "dict",
            "type_name": "dict",
            "entries": entries,
            "elided_count": container_omitted + edge_omitted,
        }

    def _function_node(self, uid: int, value: types.FunctionType) -> HeapNode:
        module = object.__getattribute__(value, "__module__")
        node: HeapNode = {
            "uid": uid,
            "kind": "function",
            "type_name": "function",
            "module": module if type(module) is str else "",
            "qualname": object.__getattribute__(value, "__qualname__"),
            "provenance": "unknown",
        }
        if self._provenance_resolver is not None:
            frame_id = self._provenance_resolver.resolve(value)
            if frame_id in self._current_frame_ids:
                node["provenance"] = "resolved"
                node["defining_frame_id"] = frame_id

        environment_id = self._closure_environment(value)
        if environment_id is False:
            return {
                "uid": uid,
                "kind": "elided",
                "type_name": "function",
                "reason": "node_limit",
            }
        if environment_id is not None:
            node["closure_environment_id"] = environment_id
        # BOTGINEER PATCH (PATCHES.md): a function object's positional
        # defaults are built once, at def time, and belong to the function.
        # Emitting them is what lets a trace show a shared `log=[]`.
        defaults = object.__getattribute__(value, "__defaults__")
        if defaults:
            node["defaults"] = [self._encode_edge(item) for item in defaults]
        return node

    def _closure_environment(self, function: types.FunctionType) -> int | None | Literal[False]:
        closure = object.__getattribute__(function, "__closure__")
        if closure is None:
            return None
        code = object.__getattribute__(function, "__code__")
        freevars = code.co_freevars
        if len(freevars) != len(closure):
            raise RuntimeError("function closure metadata is inconsistent")

        new_cell_raw_ids = {id(cell) for cell in closure if id(cell) not in self._uid_by_raw_id}
        if len(self._memo) + len(new_cell_raw_ids) > self._options.max_heap_nodes:
            self._heap_elided = True
            return False

        key = tuple((name, id(cell)) for name, cell in zip(freevars, closure, strict=True))
        cells: list[dict[str, Any]] = []
        for name, cell in zip(freevars, closure, strict=True):
            encoded = self._encode_value(cell)
            if encoded.get("kind") != "ref":
                self._heap_elided = True
                return False
            cells.append({"name": name, "value": encoded})

        environment_id = self._closure_environment_by_key.get(key)
        if environment_id is not None:
            return environment_id
        environment_id = len(self._closure_environment_by_key) + 1
        self._closure_environment_by_key[key] = environment_id
        self._closure_environments[environment_id] = {
            "environment_id": environment_id,
            "cells": cells,
        }
        return environment_id

    def _class_node(self, uid: int, value: type[object]) -> HeapNode:
        module = self._class_text(value, "__module__")
        if not self._module_is_visible(module):
            return self._opaque_node(uid, value, "imported")

        bases = type.__getattribute__(value, "__bases__")
        encoded_bases = [self._encode_edge(base) for base in bases]
        attributes = self._encode_attributes(self._class_dictionary(value))
        return {
            "uid": uid,
            "kind": "class",
            "type_name": self._type_name(value),
            "module": module,
            "qualname": self._class_text(value, "__qualname__"),
            "bases": encoded_bases,
            "attributes": attributes,
        }

    def _instance_node(self, uid: int, value: object) -> HeapNode:
        value_type = type(value)
        module = self._class_text(value_type, "__module__")
        if not self._module_is_visible(module):
            return self._opaque_node(uid, value, "imported")

        attributes = self._safe_instance_attributes(value)
        if attributes is None:
            return self._opaque_node(uid, value, "unsafe_access")
        return {
            "uid": uid,
            "kind": "instance",
            "type_name": self._type_name(value_type),
            "class_module": module,
            "class_qualname": self._class_text(value_type, "__qualname__"),
            "attributes": self._encode_attributes(attributes),
        }

    def _generator_node(self, uid: int, value: Generator[Any, Any, Any]) -> HeapNode:
        states = {
            inspect.GEN_CREATED: "created",
            inspect.GEN_RUNNING: "running",
            inspect.GEN_SUSPENDED: "suspended",
            inspect.GEN_CLOSED: "closed",
        }
        return {
            "uid": uid,
            "kind": "generator",
            "type_name": "generator",
            "state": states[inspect.getgeneratorstate(value)],
        }

    def _cell_node(self, uid: int, value: types.CellType) -> HeapNode:
        try:
            content = value.cell_contents
        except ValueError:
            return {"uid": uid, "kind": "cell", "type_name": "cell", "state": "empty"}
        return {
            "uid": uid,
            "kind": "cell",
            "type_name": "cell",
            "state": "value",
            "content": self._encode_edge(content),
        }

    @staticmethod
    def _module_node(uid: int, value: types.ModuleType) -> HeapNode:
        return {
            "uid": uid,
            "kind": "module",
            "type_name": "module",
            "module": types.ModuleType.__getattribute__(value, "__name__"),
        }

    def _opaque_node(
        self,
        uid: int,
        value: object,
        reason: str,
    ) -> HeapNode:
        return {
            "uid": uid,
            "kind": "opaque",
            "type_name": self._type_name(type(value)),
            "reason": reason,
        }

    def _safe_instance_attributes(self, value: object) -> dict[str, object] | None:
        attributes: dict[str, object] = {}
        value_type = type(value)
        for base in type.__getattribute__(value_type, "__mro__"):
            namespace = self._class_dictionary(base)
            dictionary_descriptor = namespace.get("__dict__", _MISSING)
            if type(dictionary_descriptor) is types.GetSetDescriptorType:
                try:
                    instance_dictionary = dictionary_descriptor.__get__(value, value_type)
                except AttributeError:
                    pass
                else:
                    if type(instance_dictionary) is not dict:
                        return None
                    if any(type(name) is not str for name in instance_dictionary):
                        return None
                    attributes.update(instance_dictionary)
                break

        for base in type.__getattribute__(value_type, "__mro__"):
            namespace = self._class_dictionary(base)
            for name, descriptor in namespace.items():
                if type(name) is not str or type(descriptor) is not types.MemberDescriptorType:
                    continue
                if not self._show_attribute(name):
                    continue
                try:
                    slot_value = descriptor.__get__(value, value_type)
                except AttributeError:
                    continue
                attributes[name] = slot_value
        return attributes

    def _encode_attributes(self, attributes: dict[str, object]) -> list[dict[str, Any]]:
        selected = [
            (name, value)
            for name, value in sorted(attributes.items())
            if self._show_attribute(name)
        ]
        if len(selected) > self._options.max_container_elems:
            selected = selected[: self._options.max_container_elems]
            self._container_elided = True
        result: list[dict[str, Any]] = []
        for name, value in selected:
            result.append({"name": name, "value": self._encode_edge(value)})
        return result

    def _show_attribute(self, name: str) -> bool:
        return self._options.show_dunder_attributes or not (
            len(name) >= 4 and name.startswith("__") and name.endswith("__")
        )

    def _module_is_visible(self, module: str) -> bool:
        return module == "__main__" or module in self._options.trace_modules

    @staticmethod
    def _class_dictionary(value: type[object]) -> dict[str, object]:
        namespace = type.__getattribute__(value, "__dict__")
        return dict(namespace)

    @staticmethod
    def _class_text(value: type[object], name: str) -> str:
        result = type.__getattribute__(value, name)
        return result if type(result) is str else ""

    @staticmethod
    def _type_name(value: type[object]) -> str:
        result = type.__getattribute__(value, "__name__")
        return result if type(result) is str else ""

    @staticmethod
    def _is_iterator_type(value_type: type[object]) -> bool:
        for base in type.__getattribute__(value_type, "__mro__"):
            namespace = type.__getattribute__(base, "__dict__")
            if "__next__" in namespace:
                return True
        return False

    @staticmethod
    def _is_class_object(value_type: type[object]) -> bool:
        return type in type.__getattribute__(value_type, "__mro__")

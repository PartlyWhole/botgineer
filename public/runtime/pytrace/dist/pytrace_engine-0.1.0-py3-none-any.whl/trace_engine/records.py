"""Schema-facing record types used by the dependency-free engine."""

from __future__ import annotations

from typing import Any

type JSONScalar = None | bool | int | float | str
type JSONValue = JSONScalar | list[JSONValue] | dict[str, JSONValue]
type Record = dict[str, Any]
type EncodedValue = dict[str, Any]
type HeapNode = dict[str, Any]

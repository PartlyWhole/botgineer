"""Validated immutable options for one PyTrace run."""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass
from typing import Final

_COUNT_FIELDS: Final = (
    "max_steps",
    "max_heap_nodes",
    "max_heap_edges",
    "max_container_elems",
    "max_output_bytes",
    "max_record_bytes",
    "max_trace_bytes",
    "max_source_bytes",
    "max_input_line_bytes",
    "identity_tombstones",
)


@dataclass(frozen=True, slots=True)
class TraceOptions:
    """Approved per-run limits and behavior switches."""

    max_steps: int = 1000
    max_heap_nodes: int = 500
    max_heap_edges: int = 2000
    max_container_elems: int = 120
    max_output_bytes: int = 256 * 1024
    max_record_bytes: int = 2 * 1024 * 1024
    max_trace_bytes: int = 32 * 1024 * 1024
    max_source_bytes: int = 1024 * 1024
    max_input_line_bytes: int = 64 * 1024
    wall_clock_s: float = 10
    identity_tombstones: int = 2048
    trace_modules: tuple[str, ...] = ()
    show_dunder_attributes: bool = False
    echo_stdin: bool = True

    def __post_init__(self) -> None:
        for name in _COUNT_FIELDS:
            value = getattr(self, name)
            if type(value) is not int or value <= 0:
                raise ValueError(f"{name} must be a positive integer")

        if isinstance(self.wall_clock_s, bool) or not isinstance(self.wall_clock_s, (int, float)):
            raise ValueError("wall_clock_s must be a finite positive number")
        if not math.isfinite(self.wall_clock_s) or self.wall_clock_s <= 0:
            raise ValueError("wall_clock_s must be a finite positive number")

        if type(self.trace_modules) is not tuple:
            raise ValueError("trace_modules must be a tuple")
        if any(type(name) is not str or not name for name in self.trace_modules):
            raise ValueError("trace_modules must contain unique non-empty exact strings")
        if len(set(self.trace_modules)) != len(self.trace_modules):
            raise ValueError("trace_modules must contain unique module names")
        if type(self.show_dunder_attributes) is not bool:
            raise ValueError("show_dunder_attributes must be a boolean")
        if type(self.echo_stdin) is not bool:
            raise ValueError("echo_stdin must be a boolean")

    def to_record(self) -> dict[str, object]:
        """Return the schema representation of these immutable options."""

        result = asdict(self)
        result["trace_modules"] = list(self.trace_modules)
        return result

"""Continuous-observation identity without unbounded object retention."""

from __future__ import annotations

import weakref
from collections import OrderedDict
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class IdentityResolution:
    uid: int
    ambiguous: bool


@dataclass(slots=True)
class _IdentityEntry:
    uid: int
    raw_id: int
    weak: weakref.ReferenceType[object] | None
    strong: object | None
    last_seen_generation: int

    def matches(self, value: object) -> bool:
        if self.weak is not None:
            return self.weak() is value
        return self.strong is value


class IdentityRegistry:
    """Allocate monotonic UIDs while an object remains continuously visible."""

    def __init__(self, tombstone_limit: int) -> None:
        if type(tombstone_limit) is not int or tombstone_limit <= 0:
            raise ValueError("tombstone_limit must be a positive integer")
        self._tombstone_limit = tombstone_limit
        self._next_uid = 1
        self._generation = 0
        self._last_completed_generation = 0
        self._entries: dict[int, _IdentityEntry] = {}
        self._tombstones: OrderedDict[int, None] = OrderedDict()
        self._snapshot_active = False
        self._snapshot_new_raw_ids: set[int] = set()
        self._snapshot_touched_raw_ids: set[int] = set()
        self._snapshot_consumed_tombstones: set[int] = set()

    @property
    def tombstone_limit(self) -> int:
        return self._tombstone_limit

    @property
    def active_count(self) -> int:
        return len(self._entries)

    @property
    def tombstone_count(self) -> int:
        return len(self._tombstones)

    @property
    def next_uid(self) -> int:
        return self._next_uid

    def begin_snapshot(self) -> None:
        if self._snapshot_active:
            raise RuntimeError("identity snapshot is already active")
        self._generation += 1
        self._snapshot_active = True
        self._snapshot_new_raw_ids.clear()
        self._snapshot_touched_raw_ids.clear()
        self._snapshot_consumed_tombstones.clear()

    def observe(self, value: object) -> IdentityResolution:
        if not self._snapshot_active:
            raise RuntimeError("begin_snapshot must be called before observe")
        raw_id = id(value)
        entry = self._entries.get(raw_id)
        if entry is not None and entry.matches(value):
            entry.last_seen_generation = self._generation
            self._snapshot_touched_raw_ids.add(raw_id)
            return IdentityResolution(entry.uid, ambiguous=False)
        if entry is not None:
            self._retire(raw_id, entry)

        ambiguous = raw_id in self._tombstones
        if ambiguous:
            del self._tombstones[raw_id]
            self._snapshot_consumed_tombstones.add(raw_id)
        uid = self._next_uid
        self._next_uid += 1
        entry = self._new_entry(value, uid, raw_id)
        self._entries[raw_id] = entry
        self._snapshot_new_raw_ids.add(raw_id)
        return IdentityResolution(uid, ambiguous=ambiguous)

    def end_snapshot(self) -> None:
        if not self._snapshot_active:
            raise RuntimeError("identity snapshot is not active")
        for raw_id, entry in list(self._entries.items()):
            if entry.last_seen_generation != self._generation:
                self._retire(raw_id, entry)
        self._last_completed_generation = self._generation
        self._snapshot_active = False
        self._snapshot_new_raw_ids.clear()
        self._snapshot_touched_raw_ids.clear()
        self._snapshot_consumed_tombstones.clear()

    def abort_snapshot(self) -> None:
        """Discard observations that did not produce a host-visible snapshot."""

        if not self._snapshot_active:
            return
        for raw_id in tuple(self._snapshot_new_raw_ids):
            entry = self._entries.get(raw_id)
            if entry is not None and entry.last_seen_generation == self._generation:
                del self._entries[raw_id]
            if raw_id in self._snapshot_consumed_tombstones:
                self._add_tombstone(raw_id)
            else:
                self._tombstones.pop(raw_id, None)
        for raw_id in self._snapshot_touched_raw_ids:
            entry = self._entries.get(raw_id)
            if entry is not None and entry.last_seen_generation == self._generation:
                entry.last_seen_generation = self._last_completed_generation
        self._snapshot_active = False
        self._snapshot_new_raw_ids.clear()
        self._snapshot_touched_raw_ids.clear()
        self._snapshot_consumed_tombstones.clear()

    def is_tombstoned(self, raw_id: int) -> bool:
        return raw_id in self._tombstones

    def retain_visible_uids(self, visible_uids: set[int]) -> None:
        """Retire objects structurally removed before a snapshot is emitted."""

        if self._snapshot_active:
            raise RuntimeError("cannot reconcile an active identity snapshot")
        for raw_id, entry in list(self._entries.items()):
            if entry.uid not in visible_uids:
                self._retire(raw_id, entry)

    def _new_entry(self, value: object, uid: int, raw_id: int) -> _IdentityEntry:
        registry_ref = weakref.ref(self)

        def retired(reference: weakref.ReferenceType[object]) -> None:
            registry = registry_ref()
            if registry is not None:
                registry._weak_value_retired(raw_id, uid, reference)

        try:
            reference = weakref.ref(value, retired)
        except TypeError:
            reference = None
            strong: object | None = value
        else:
            strong = None
        return _IdentityEntry(
            uid=uid,
            raw_id=raw_id,
            weak=reference,
            strong=strong,
            last_seen_generation=self._generation,
        )

    def _weak_value_retired(
        self,
        raw_id: int,
        uid: int,
        reference: weakref.ReferenceType[object],
    ) -> None:
        entry = self._entries.get(raw_id)
        if entry is not None and entry.uid == uid and entry.weak is reference:
            self._retire(raw_id, entry)

    def _retire(self, raw_id: int, entry: _IdentityEntry) -> None:
        current = self._entries.get(raw_id)
        if current is entry:
            del self._entries[raw_id]
        self._add_tombstone(raw_id)

    def _add_tombstone(self, raw_id: int) -> None:
        self._tombstones[raw_id] = None
        self._tombstones.move_to_end(raw_id)
        while len(self._tombstones) > self._tombstone_limit:
            self._tombstones.popitem(last=False)


class FrameIdAllocator:
    """Allocate frame invocation IDs without retaining frame objects."""

    def __init__(self) -> None:
        self._next_id = 1

    def allocate(self) -> int:
        frame_id = self._next_id
        self._next_id += 1
        return frame_id

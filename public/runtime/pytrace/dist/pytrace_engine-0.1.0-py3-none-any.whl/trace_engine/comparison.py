"""Semantic snapshot comparison that ignores unstable identity numbers and set wire order."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .records import Record


def snapshots_semantically_equal(left: Record, right: Record) -> bool:
    """Compare complete step snapshots using the approved semantic determinism rules."""

    if left.get("kind") != "step" or right.get("kind") != "step":
        raise ValueError("two step records are required")
    comparison = _SnapshotComparison.from_records(left, right)
    return comparison.compare()


@dataclass(slots=True)
class _SnapshotComparison:
    left: Record
    right: Record
    left_nodes: dict[int, dict[str, Any]]
    right_nodes: dict[int, dict[str, Any]]
    left_environments: dict[int, dict[str, Any]]
    right_environments: dict[int, dict[str, Any]]
    left_frames: dict[int, int]
    right_frames: dict[int, int]
    uid_map: dict[int, int] = field(default_factory=dict)
    reverse_uid_map: dict[int, int] = field(default_factory=dict)
    environment_map: dict[int, int] = field(default_factory=dict)
    reverse_environment_map: dict[int, int] = field(default_factory=dict)
    compared_uid_pairs: set[tuple[int, int]] = field(default_factory=set)

    @classmethod
    def from_records(cls, left: Record, right: Record) -> _SnapshotComparison:
        left_heap = left.get("heap")
        right_heap = right.get("heap")
        left_envs = left.get("closure_environments")
        right_envs = right.get("closure_environments")
        left_stack = left.get("stack")
        right_stack = right.get("stack")
        if not isinstance(left_heap, list) or not isinstance(right_heap, list):
            return cls(left, right, {}, {}, {}, {}, {}, {})
        if not isinstance(left_envs, list) or not isinstance(right_envs, list):
            return cls(left, right, {}, {}, {}, {}, {}, {})
        if not isinstance(left_stack, list) or not isinstance(right_stack, list):
            return cls(left, right, {}, {}, {}, {}, {}, {})
        return cls(
            left=left,
            right=right,
            left_nodes=_objects_by_integer_key(left_heap, "uid"),
            right_nodes=_objects_by_integer_key(right_heap, "uid"),
            left_environments=_objects_by_integer_key(left_envs, "environment_id"),
            right_environments=_objects_by_integer_key(right_envs, "environment_id"),
            left_frames=_frame_positions(left_stack),
            right_frames=_frame_positions(right_stack),
        )

    def compare(self) -> bool:
        if not self.left_nodes and self.left.get("heap"):
            return False
        if not self.right_nodes and self.right.get("heap"):
            return False
        for name in ("event", "location", "output", "flags"):
            if self.left.get(name) != self.right.get(name):
                return False
        if not self._compare_stack():
            return False
        if not self._compare_globals():
            return False
        if not self._compare_optional_value(
            self.left.get("event_data"), self.right.get("event_data")
        ):
            return False
        return len(self.left_nodes) == len(self.right_nodes) and len(self.uid_map) == len(
            self.left_nodes
        )

    def _compare_stack(self) -> bool:
        left_stack = self.left.get("stack")
        right_stack = self.right.get("stack")
        assert isinstance(left_stack, list) and isinstance(right_stack, list)
        if len(left_stack) != len(right_stack):
            return False
        for left_frame, right_frame in zip(left_stack, right_stack, strict=True):
            if not isinstance(left_frame, dict) or not isinstance(right_frame, dict):
                return False
            for name in ("function", "module", "location"):
                if left_frame.get(name) != right_frame.get(name):
                    return False
            if not self._compare_bindings(left_frame.get("locals"), right_frame.get("locals")):
                return False
        return True

    def _compare_globals(self) -> bool:
        left_globals = self.left.get("globals")
        right_globals = self.right.get("globals")
        if not isinstance(left_globals, list) or not isinstance(right_globals, list):
            return False
        if len(left_globals) != len(right_globals):
            return False
        for left_scope, right_scope in zip(left_globals, right_globals, strict=True):
            if not isinstance(left_scope, dict) or not isinstance(right_scope, dict):
                return False
            if left_scope.get("module") != right_scope.get("module"):
                return False
            if not self._compare_bindings(left_scope.get("bindings"), right_scope.get("bindings")):
                return False
        return True

    def _compare_bindings(self, left: object, right: object) -> bool:
        if not isinstance(left, list) or not isinstance(right, list) or len(left) != len(right):
            return False
        for left_binding, right_binding in zip(left, right, strict=True):
            if not isinstance(left_binding, dict) or not isinstance(right_binding, dict):
                return False
            if left_binding.get("name") != right_binding.get("name"):
                return False
            if not self._compare_value(left_binding.get("value"), right_binding.get("value")):
                return False
        return True

    def _compare_optional_value(self, left: object, right: object) -> bool:
        if left is None or right is None:
            return left is None and right is None
        return self._compare_value(left, right)

    def _compare_value(self, left: object, right: object) -> bool:
        if isinstance(left, dict) and isinstance(right, dict):
            if left.get("kind") == "ref" or right.get("kind") == "ref":
                if left.get("kind") != "ref" or right.get("kind") != "ref":
                    return False
                left_uid = left.get("uid")
                right_uid = right.get("uid")
                if type(left_uid) is not int or type(right_uid) is not int:
                    return False
                return self._compare_ref(left_uid, right_uid)
            if set(left) != set(right):
                return False
            return all(self._compare_value(left[name], right[name]) for name in left)
        if isinstance(left, list) and isinstance(right, list):
            return len(left) == len(right) and all(
                self._compare_value(left_item, right_item)
                for left_item, right_item in zip(left, right, strict=True)
            )
        return left == right and type(left) is type(right)

    def _compare_ref(self, left_uid: int, right_uid: int) -> bool:
        mapped = self.uid_map.get(left_uid)
        if mapped is not None:
            return mapped == right_uid
        if right_uid in self.reverse_uid_map:
            return False
        left_node = self.left_nodes.get(left_uid)
        right_node = self.right_nodes.get(right_uid)
        if left_node is None or right_node is None:
            return False
        self.uid_map[left_uid] = right_uid
        self.reverse_uid_map[right_uid] = left_uid
        pair = (left_uid, right_uid)
        if pair in self.compared_uid_pairs:
            return True
        self.compared_uid_pairs.add(pair)
        return self._compare_node(left_node, right_node)

    def _compare_node(self, left: dict[str, Any], right: dict[str, Any]) -> bool:
        if left.get("kind") != right.get("kind"):
            return False
        kind = left.get("kind")
        if type(kind) is not str:
            return False
        ignored = {"uid"}
        if kind == "function":
            ignored |= {"defining_frame_id", "closure_environment_id"}
        elif kind == "generator":
            ignored.add("frame_id")
        child_fields = {
            "list": {"items"},
            "tuple": {"items"},
            "set": {"items"},
            "frozenset": {"items"},
            "dict": {"entries"},
            "class": {"bases", "attributes"},
            "instance": {"attributes"},
            "cell": {"content"},
        }.get(kind, set())
        metadata_keys = (set(left) | set(right)) - ignored - child_fields
        if any(left.get(name) != right.get(name) for name in metadata_keys):
            return False

        if kind in {"list", "tuple"}:
            return self._compare_ordered_values(left.get("items"), right.get("items"))
        if kind in {"set", "frozenset"}:
            if left.get("ordering") == "unordered":
                return self._compare_unordered_values(left.get("items"), right.get("items"))
            return self._compare_ordered_values(left.get("items"), right.get("items"))
        if kind == "dict":
            return self._compare_entries(left.get("entries"), right.get("entries"))
        if kind == "class":
            return self._compare_ordered_values(
                left.get("bases"), right.get("bases")
            ) and self._compare_bindings(left.get("attributes"), right.get("attributes"))
        if kind == "instance":
            return self._compare_bindings(left.get("attributes"), right.get("attributes"))
        if kind == "cell" and left.get("state") == "value":
            return self._compare_value(left.get("content"), right.get("content"))
        if kind == "function":
            if left.get("provenance") == "resolved" and not self._compare_frame_ids(
                left.get("defining_frame_id"), right.get("defining_frame_id")
            ):
                return False
            return self._compare_environment_ids(
                left.get("closure_environment_id"), right.get("closure_environment_id")
            )
        if kind == "generator" and ("frame_id" in left or "frame_id" in right):
            return self._compare_frame_ids(left.get("frame_id"), right.get("frame_id"))
        return True

    def _compare_ordered_values(self, left: object, right: object) -> bool:
        if not isinstance(left, list) or not isinstance(right, list) or len(left) != len(right):
            return False
        return all(
            self._compare_value(left_item, right_item)
            for left_item, right_item in zip(left, right, strict=True)
        )

    def _compare_unordered_values(self, left: object, right: object) -> bool:
        if not isinstance(left, list) or not isinstance(right, list) or len(left) != len(right):
            return False
        return self._match_unordered(left, right, set(), 0)

    def _match_unordered(
        self,
        left: list[object],
        right: list[object],
        used_right: set[int],
        index: int,
    ) -> bool:
        if index == len(left):
            return True
        signature = self._value_signature(left[index], self.left_nodes)
        for right_index, candidate in enumerate(right):
            if right_index in used_right:
                continue
            if signature != self._value_signature(candidate, self.right_nodes):
                continue
            trial = self._clone()
            if not trial._compare_value(left[index], candidate):
                continue
            if trial._match_unordered(left, right, used_right | {right_index}, index + 1):
                self._adopt(trial)
                return True
        return False

    def _compare_entries(self, left: object, right: object) -> bool:
        if not isinstance(left, list) or not isinstance(right, list) or len(left) != len(right):
            return False
        for left_entry, right_entry in zip(left, right, strict=True):
            if not isinstance(left_entry, dict) or not isinstance(right_entry, dict):
                return False
            if not self._compare_value(left_entry.get("key"), right_entry.get("key")):
                return False
            if not self._compare_value(left_entry.get("value"), right_entry.get("value")):
                return False
        return True

    def _compare_environment_ids(self, left: object, right: object) -> bool:
        if left is None or right is None:
            return left is None and right is None
        if type(left) is not int or type(right) is not int:
            return False
        mapped = self.environment_map.get(left)
        if mapped is not None:
            return mapped == right
        if right in self.reverse_environment_map:
            return False
        left_environment = self.left_environments.get(left)
        right_environment = self.right_environments.get(right)
        if left_environment is None or right_environment is None:
            return False
        self.environment_map[left] = right
        self.reverse_environment_map[right] = left
        return self._compare_bindings(left_environment.get("cells"), right_environment.get("cells"))

    def _compare_frame_ids(self, left: object, right: object) -> bool:
        if type(left) is not int or type(right) is not int:
            return False
        return self.left_frames.get(left) == self.right_frames.get(right)

    def _value_signature(
        self,
        value: object,
        nodes: dict[int, dict[str, Any]],
    ) -> tuple[object, ...]:
        if not isinstance(value, dict):
            return (type(value).__name__,)
        if value.get("kind") != "ref":
            return ("inline", value.get("kind"), tuple(sorted(value)))
        uid = value.get("uid")
        node = nodes.get(uid) if type(uid) is int else None
        if node is None:
            return ("dangling",)
        return (
            "ref",
            node.get("kind"),
            node.get("type_name"),
            node.get("class_module"),
            node.get("class_qualname"),
            node.get("module"),
            node.get("qualname"),
            node.get("reason"),
        )

    def _clone(self) -> _SnapshotComparison:
        return _SnapshotComparison(
            left=self.left,
            right=self.right,
            left_nodes=self.left_nodes,
            right_nodes=self.right_nodes,
            left_environments=self.left_environments,
            right_environments=self.right_environments,
            left_frames=self.left_frames,
            right_frames=self.right_frames,
            uid_map=dict(self.uid_map),
            reverse_uid_map=dict(self.reverse_uid_map),
            environment_map=dict(self.environment_map),
            reverse_environment_map=dict(self.reverse_environment_map),
            compared_uid_pairs=set(self.compared_uid_pairs),
        )

    def _adopt(self, other: _SnapshotComparison) -> None:
        self.uid_map = other.uid_map
        self.reverse_uid_map = other.reverse_uid_map
        self.environment_map = other.environment_map
        self.reverse_environment_map = other.reverse_environment_map
        self.compared_uid_pairs = other.compared_uid_pairs


def _objects_by_integer_key(values: list[object], key: str) -> dict[int, dict[str, Any]]:
    result: dict[int, dict[str, Any]] = {}
    for value in values:
        if not isinstance(value, dict):
            return {}
        identifier = value.get(key)
        if type(identifier) is not int or identifier in result:
            return {}
        result[identifier] = value
    return result


def _frame_positions(values: list[object]) -> dict[int, int]:
    result: dict[int, int] = {}
    for position, value in enumerate(values):
        if not isinstance(value, dict):
            return {}
        frame_id = value.get("frame_id")
        if type(frame_id) is not int or frame_id in result:
            return {}
        result[frame_id] = position
    return result

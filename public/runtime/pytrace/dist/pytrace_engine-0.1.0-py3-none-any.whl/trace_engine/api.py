"""Public in-process host contracts."""

from __future__ import annotations

from collections import deque
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from typing import Literal, Protocol

from .records import Record

type TerminalReason = Literal[
    "completed",
    "uncaught_exception",
    "step_limit",
    "trace_limit",
    "needs_input",
    "interrupted",
    "killed",
    "engine_error",
]
type InputMode = Literal["live", "pre_supplied"]


class TraceSink(Protocol):
    def emit(self, record: Record) -> None: ...


class InputProvider(Protocol):
    input_mode: InputMode

    def provide_input(self, request_id: str, prompt: str) -> str | None: ...


@dataclass(frozen=True, slots=True)
class RunSummary:
    run_id: str
    terminal_reason: TerminalReason
    terminal_seq: int
    step_count: int
    diagnostic_count: int
    stdout_bytes: int
    stderr_bytes: int
    trace_bytes: int
    trace_complete: bool


class ListTraceSink:
    """In-memory sink used by the collection convenience API."""

    def __init__(self) -> None:
        self.records: list[Record] = []

    def emit(self, record: Record) -> None:
        self.records.append(record)


class QueueInputProvider:
    """Finite pre-supplied input with no replay."""

    input_mode: InputMode = "pre_supplied"

    def __init__(self, lines: Iterable[str] = ()) -> None:
        self._lines = deque(lines)

    def provide_input(self, request_id: str, prompt: str) -> str | None:
        del request_id, prompt
        return self._lines.popleft() if self._lines else None


class CallableInputProvider:
    """Live synchronous input adapter for trusted embedding."""

    input_mode: InputMode = "live"

    def __init__(self, callback: Callable[[str, str], str | None]) -> None:
        self._callback = callback

    def provide_input(self, request_id: str, prompt: str) -> str | None:
        return self._callback(request_id, prompt)


class InputCancelled(Exception):
    """Host-side cooperative cancellation of one outstanding input request."""


class TraceConflictError(RuntimeError):
    """An unrelated trace function is already active."""

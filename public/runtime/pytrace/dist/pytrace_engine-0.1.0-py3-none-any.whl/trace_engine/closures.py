"""Static lexical provenance and live invocation resolution."""

from __future__ import annotations

import types
from collections import deque
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class LexicalParentMap:
    root: types.CodeType
    _parents: dict[int, tuple[types.CodeType, types.CodeType]]

    @classmethod
    def from_source(cls, source: str, filename: str = "<pytrace>") -> LexicalParentMap:
        if type(source) is not str:
            raise TypeError("source must be an exact string")
        return cls.from_code(compile(source, filename, "exec", dont_inherit=True))

    @classmethod
    def from_code(cls, root: types.CodeType) -> LexicalParentMap:
        parents: dict[int, tuple[types.CodeType, types.CodeType]] = {}
        pending = deque([root])
        while pending:
            parent = pending.popleft()
            for constant in parent.co_consts:
                if type(constant) is not types.CodeType:
                    continue
                child = constant
                parents[id(child)] = (child, parent)
                pending.append(child)
        return cls(root=root, _parents=parents)

    def parent_of(self, code: types.CodeType) -> types.CodeType | None:
        entry = self._parents.get(id(code))
        if entry is None or entry[0] is not code:
            return None
        return entry[1]


class ActiveInvocations:
    """Track only live code-to-frame-ID associations."""

    def __init__(self) -> None:
        self._by_code: dict[int, tuple[types.CodeType, set[int]]] = {}

    def register(self, code: types.CodeType, frame_id: int) -> None:
        if type(frame_id) is not int or frame_id <= 0:
            raise ValueError("frame_id must be a positive integer")
        raw_id = id(code)
        entry = self._by_code.get(raw_id)
        if entry is None:
            entry = (code, set())
            self._by_code[raw_id] = entry
        elif entry[0] is not code:
            raise RuntimeError("live code identity collision")
        entry[1].add(frame_id)

    def unregister(self, code: types.CodeType, frame_id: int) -> None:
        raw_id = id(code)
        entry = self._by_code.get(raw_id)
        if entry is None or entry[0] is not code:
            return
        frame_ids = entry[1]
        frame_ids.discard(frame_id)
        if not frame_ids:
            del self._by_code[raw_id]

    def unique_frame_id(self, code: types.CodeType) -> int | None:
        entry = self._by_code.get(id(code))
        if entry is None or entry[0] is not code:
            return None
        frame_ids = entry[1]
        if len(frame_ids) != 1:
            return None
        return next(iter(frame_ids))


@dataclass(frozen=True, slots=True)
class FunctionProvenanceResolver:
    lexical_parents: LexicalParentMap
    active_invocations: ActiveInvocations

    def resolve(self, function: types.FunctionType) -> int | None:
        code = object.__getattribute__(function, "__code__")
        parent = self.lexical_parents.parent_of(code)
        if parent is None:
            return None
        return self.active_invocations.unique_frame_id(parent)
